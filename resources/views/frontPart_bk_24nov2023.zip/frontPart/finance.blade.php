@php $pageMeta = App\Models\StaticPageMetaTag::where('page_name','finance')->first(); @endphp

@if(isset($pageMeta) && !empty($pageMeta))
@section('title',$pageMeta->page_title)
@section('meta_keywords',$pageMeta->page_keyword)
@section('meta_description',$pageMeta->page_description)
@endif
@extends('layouts.front')

@section('content')
    
    <!--about banner-->
    <section class="jobbanner-section finance_top_banner">
        <div class="jobbanner-text">
            <h1>Finance</h1>
        </div>
    </section>
    <!--about banner-->
    
    <!-- about page section  -->
    <section class="guldenland_section about_page_content mt-5">
        <div class="container">
            <div class="heading">
                <div class="manage-paragraph text-justify">
                    <p>Trafalgar Financial Services (“TFS”) is an authorised financial services and credit provider with a specialist property finance focus for all juristic, residential entities including, but not limited to, sectional title bodies corporate, non-profit home owners’ associations, share block companies and property owning entities. With a loan book in excess of R100 million, Trafalgar Financial Services is one of the largest, niche financiers, of residential complexes in South Africa.</p>
                </div>
            </div>
            <div class="property-solution online_services_view mb-4">
                <div class="container">
                    <div class="online_services_ mt-4">
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img class="img-fluid" src="{{ asset('front/images/loan.svg') }}" alt="loan">
                            </div>
                            <h5>Body Corporate Loans</h5>
                            <p>Short term finance for maintenance projects or other building requirements</p>
                            @php $url1 =  route('body-corporate-hoa-and-share-block-loans')  @endphp
                            <a href="#bodyCorporateDiv" class="theme-btn">Read More</a>
                            <!--<button onclick="window.location.href='{{ $url1}}'" class="theme-btn">Read More</button>-->
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="{{ asset('front/images/finance.svg') }}" alt="finance">
                            </div>
                            <h5>Levy Finance</h5>
                            <p>Eliminate the cash flow pressures of late or arrear levy payments</p>
                            <a  href="#levyFinance" class="theme-btn">Read More</a>
                            <!--<button  onclick="window.location.href='#'" class="theme-btn">Read More</button>-->
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="{{ asset('front/images/trafex.svg') }}" alt="trafex">
                            </div>
                            <h5>Trafex</h5>
                            <p>Safeguard against unexpected and unpleasant insurance excesses</p>
                            <a  href="#trafexDiv" class="theme-btn">Read More</a>
                            <!--<button  onclick="window.location.href='#'" class="theme-btn">Read More</button>-->
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="{{ asset('front/images/contact.svg') }}" alt="contact">
                            </div>
                            <h5>Contact Us</h5>
                            <p>Contact us direct for a broker to be in touch with you</p>
                             @php $url2 =  route('contact-us')  @endphp
                              <a  href="#contactUsDiv" class="theme-btn">Read More</a>
                            <!--<button  onclick="window.location.href='{{ $url2 }}'" class="theme-btn">Read More</button>-->
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="{{ asset('front/images/owners.svg') }}" alt="owners">
                            </div>
                            <h5>Finance For Residential Owners</h5>
                            <p>Loan finance for property investors wanting to refurbish their complexes to increase rentals and reduce vacancies</p>
                            @php $url2 =  route('body-corporate-hoa-and-share-block-loans')  @endphp
                              <a   href="#bodyCorporateDiv" class="theme-btn">Read More</a>
                            <!--<button class="theme-btn" onclick="window.location.href='{{ $url2 }}'" >Read More</button>-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing">
                    <div class="each_manage_section" id="bodyCorporateDiv">
                        <h4><a href="javascript:void(0)">BODY CORPORATE, HOA AND SHARE BLOCK LOANS</a></h4>
                        <div class="more-content">
                            <p>Typically speaking, bodies corporate, Home Owners Associations (HOA’s) and share block companies budget for, and accumulate, surpluses for large maintenance projects either in the ordinary budget or via special levy over term (which can be anywhere up to five years). Too often these monies are absorbed into the monthly operational costs of the body corporate / HOA or get diverted into alternate projects for which they were never (initially) intended. Further, the Act is quite restrictive in terms of where surplus monies can be invested (PMR41, PMR42 and PMR43) arguably heightening the opportunity cost of this method of fund accumulation (said legislation applicable to bodies corporate while the MOI of the HOA would govern same); sector inflation being unknown, and not reported on by STATS SA, also means that the project cost is, in essence, a moving target further complicating the process of raising monies for related maintenance or capital project(s).</p>
                            <div class="more">
                            <p class="more">Trafalgar Financial Services offers upfront finance for maintenance and capital projects on favourable terms tailor made to fit the cash flow constraints of the borrower (body corporate, HOA or share block company). More importantly, this allows for the immediate restoration or enhancement of value, on definite terms, removing any uncertainties involved with the process or project. Finance in action – Have a look at a few of our case studies:</p>
                            <ul class="pdfs">
                                <li><a href="{{ asset('storage/brochure/Elizabeth-Court.pdf') }}">Elizabeth Court</a></li>
                                <li><a href="{{ asset('storage/brochure/Kingfisher-Close.pdf') }}">Kingfisher Close</a></li>
                                <li><a href="{{ asset('storage/brochure/Meadowfields.pdf') }}">Meadowfields</a></li>
                                <li><a href="{{ asset('storage/brochure/Rydal-Mount.pdf') }}">Rydal Mount</a></li>
                            </ul>
                            </div>
                        </div>
                    </div>
                    <div class="each_manage_section" id="levyFinance">
                        <h4><a href="javascript:void(0)">LEVY FINANCE</a></h4>
                        <div class="more-content">
                            <p>Bodies corporate, home owners’ associations and share block companies are all too frequently held to ransom by some owners who default on their levy payments, resulting in cash flow problems. The vicious cycle continues with maintenance work falling progressively behind due to lack of funds and accounts falling into arrears, this further exacerbated by necessary legal fees not typically budgeted for given the assumed recoverability of said fees, albeit on completion of the legal process and not upfront. Trafalgar has a solution to this unfortunate, and not uncommon, predicament – <b>Levy Solutions</b></p>
                            <div class="more">
                                <p>Levy Solutions is a levy finance product guaranteeing a fixed monthly levy cash flow on the 1st business day of each month. This product aims to rehabilitate the buildings (body corporate, HOA or share block company) cash flow by guaranteeing levy income and delivering intensive credit control support overseen and managed by in-house attorneys; furthermore, all associated and necessary, legal fees are financed by levy solution (on a cash flow basis) ensuring the fastest, uninterrupted, rehabilitation process.</p>
                                <p>On inception of the product, Trafalgar Financial Services will immediately forward up to 90% of the property levies that are in arrears, thereby immediately relieving cash flow constraints and affording an opportunity to catch up with arrear accounts, maintenance and other priorities and, going forward, forwarding the full levy compliment on a monthly basis ensuring an uninterrupted and predictable cash flow.</p>
                                <p>Any and all incurred legal fees will also be settled by Levy Solution ensuring that the legal process continues uninterrupted to ensure the fastest rehabilitation.</p>
                                <p>With a predictable cash flow, the Body Corporate is able to plan and manage more effectively and ultimately this is very important for enhancing the asset value of the property and residents’ lifestyles.</p>
                                <b>Arrear levies result in:</b>
                                <ul>
                                    <li>A visually deteriorating complex that is unable to make repairs and sustain general maintenance</li>
                                    <li>Municipal and creditors accounts fall into arrears and interruption of services arises</li>
                                    <li>A decrease in the return on property owners’ investments.</li>
                                    <li>Poor resale values.</li>
                                    <li>Difficulties in selling units as a result of bonds refused to potential buyers.</li>
                                    <li>Compounding debt may result in special levies being raised – usually an unbudgeted item that places significant financial pressure on home owners.</li>
                                    <li>The refusal of insurance claims.</li>
                                    <li>A stressed and unhappy community of home owners.</li>
                                </ul>
                                <b>With Trafalgar’s Levy solutions, you can turn these problems around, resulting in:</b>
                                <ul>
                                    <li>Regular maintenance</li>
                                    <li>Increased property value</li>
                                    <li>Increased rental on such complexes.</li>
                                    <li>Greater opportunity to market and resale units.</li>
                                    <li>Residual funds to deal with emergencies.</li>
                                    <li>Bonds will more easily be granted to home owners.</li>
                                    <li>Enhanced lifestyles of home owners.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="each_manage_section" id="trafexDiv">
                        <h4><a href="javascript:void(0)">TRAFEX – EXCESS WAIVER AND SHORTFALL COVER</a></h4>
                        <div class="more-content">
                            <p>Insurance excesses and policy limits are both well-established norms in the insurance industry; excesses specifically, are often the first things adjusted (upwards) by insurers to address increasing loss ratios and, given owners are typically liable for excesses [PMR 29(4)], do you have the means to settle both the excess and potential shortfall unannounced and without warning?</p>
                            <p class="more">Trafalgar Financial Service’s TRAFEX Policy, being the only one of its kind in the industry, offers peace of mind and will settle all excess(s) * and shortfall(s) * arising from related insurance claims whenever and whatever the circumstances.</p>
                        </div>
                    </div>
                    <div class="each_manage_section text-center" id="contactUsDiv" >
                        <h4><a href="javascript:void(0)">CONTACT US</a></h4>
                        <p class="mb-1">Trafalgar Financial Services (TFS) after hours number for claims (this number is specifically for clients insured through TFS).</p>
                        <p class="mb-1">AFTER HOURS CLAIMS NO. FOR EXTREME EMERGENCIES: <a href="tel:072 972 0812"><b>072 972 0812</b></a></p>
                    </div>
                    <div class="contact_section p-0">
                        <div class="maintenance_form_view m-0">
                            <div class="management_form">
                            <small>Please complete the form below to contact us</small>
                           <form action="{{ route('finance-contact-mail') }}" method="post" id="finance-contact-mail">
               
                @csrf
                <div class="maintenance_form_inner">
                    <div class="field_row">
                        <div class="form-group">
                            <label for="name">Name<span>*</span></label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label for="email">Email:<span>*</span></label>
                            <input type="email" class="form-control" id="email" name="email" required >
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number:<span>*</span></label>
                            <input type="text" class="form-control" id="phone" name="phone" required>
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label for="city">City:<span>*</span></label>
                            <input type="text" class="form-control" id="city" name="city" required>
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label>Preferred method of contact<span>*</span></label>
                            <div class="radio-group">
                                <span>
                                    <input checked type="radio" id="p_phone" name="method_of_contact" value="phone" >
                                    <label for="p_phone">Phone</label>
                                </span>
                                <span>
                                    <input type="radio" value="email" id="p_email" name="method_of_contact" >
                                    <label for="p_email">Email</label>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="time_to_call">Preferred time to be called</label>
                            <input type="text" class="form-control" id="time_to_call" name="time_to_call" >
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label for="comment_or_question">Comments or Questions</label>
                            <textarea  class="form-control" id="comment_or_question" rows="3" name="comment_or_question"></textarea>
                        </div>
                    </div>
                    <div class="form-group">                                  
                <div class="g-recaptcha" data-sitekey="{{ env('GOOGLE_RECAPTCHA_KEY') }}"></div>
                @if ($errors->has('g-recaptcha-response'))
                <span class="text-danger">{{ $errors->first('g-recaptcha-response') }}</span>
                @endif
                </div> 

                    <button type="submit" class="m-0 form-control">Send message</button>
                </div>

            </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist">
                        <h4>Registration Certificates For Trafalgar Property Management (Pty) Ltd</h4>
                        <ul>
                            <li><a target="_blank" href="{{ asset('storage/websitepdf/Trafalgar Property Management PPRA Registration Certificate.pdf') }}">Property Practitioners Regulatory Authority (PPRA) Certificate
</a></li>
                            <!--<li><a target="_blank" href="asset('storage/websitepdf/Trafalgar-Property-Management-NAMA-Certificate-2022.pdf')">National Association of Managing Agents (NAMA) Certificate</a></li>-->
                            <!--<li><a target="_blank" href="asset('storage/websitepdf/Trafalgar Council for Debt Collectors Certificate 2023.pdf')">Council for Debt Collectors</a></li>-->
                            <!--<li><a target="_blank" href="asset('storage/websitepdf/Trafalgar-Professional-Indemnity-Cover-Certificate-2022.pdf')">Professional Indemnity Cover</a></li>-->
                            <!--<li><a target="_blank" href="asset('storage/websitepdf/Trafalgar-SAPOA-2022-Certificate.pdf')">South African Property Owners Association (SAPOA) Certificate</a></li>-->
                            <!--<li><a target="_blank" href="asset('storage/websitepdf/Trafalgar Property Management_BEE Certificate.pdf')">BEE Certificate</a></li>-->
                            
                        </ul>
                        
                       
                    </div>
                    <div class="sidelist">
                        <h4>Registration certificates for Trafalgar Financial Services (Pty) Ltd</h4>
                        <ul>
                            <li><a href="{{ asset('storage/trafalgarCretificate/financial-services-board.pdf') }}">Financial Services Board</a></li>
                            <li><a href="{{ asset('storage/trafalgarCretificate/Trafalgar-Financial-Services-NCR-Certificate-2021.pdf') }}">Registered Credit Provider</a></li>
                            <li><a href="{{ asset('storage/trafalgarCretificate/FIA_Membership_Certificate.tif') }}">FIA Membership Certificate</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- about page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
