@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Commercial Property Management</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            <div class="heading mb-4">
                <h2>Commercial Property Management</h2>
                <div class="manage-paragraph text-justify">
                    <p>Trafalgar offers a comprehensive and tested commercial property management service catering for all the management requirements associated with Commercial, Retail and Industrial property. Effective financial and facility management are Trafalgar’s priority focuses and competitive advantage, underpinned by well-established and customised infrastructure. Defining an accurate property budget from the outset and reporting a monthly performance to budget with the standard rent roll and creditors payment schedule, enables utility recoveries and variances to be tightly managed.</p>
                    <p>Trafalgar’s Commercial, Industrial and Retail property management services are based upon a detailed analysis of the specific requirements of the landlord as well as the inherent qualities and potential of the portfolio. We pride ourselves on offering tailored solutions to property portfolios increasing the returns to our clients. Please click here to see Trafalgar’s Commercial Property Broking & Management Brochure.</p>
                    <p>Trafalgar’s commercial property management service includes the following features:</p>
                </div>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing">
                    <div class="each_manage_section">
                        <h4><a href="#">LANDLORD SERVICES</a></h4>
                        <p>For landlords and property investors, Trafalgar’s targeted marketing ensures that your property is quickly and effectively leased to the right tenant, Trafalgar also ensures that all the correct legal processes are followed, including the latest amendments required from the recently adopted Consumer Protection Act, thereby safeguarding and maximising investor returns.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">TENANT SERVICES</a></h4>
                        <p>It is imperative that you have a clear understanding of both your rights and responsibilities as a tenant and those of the landlord, all negotiations and special conditions agreed to during the offer stage are explicitly stated in the lease agreemen</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">BROKING SERVICES</a></h4>
                        <p>Through effective marketing, in a range of communication channels, to appropriate audiences, we ensure prompt leasing in an effort to find the correct tenant mix.  This offers potential tenants a wide, convenient and accessible choice, while landlords benefit from high visibility and prompt occupation.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">ONLINE APPLICATIONS</a></h4>
                        <p>Should you wish to apply for a commercial property to rent, please download and complete the relevant application form below and return to our nearest office using the contact details provided on the <a href="#">branch locator</a> page.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">VACANCY MARKETING</a></h4>
                        <p>Through effective marketing, in a range of communication channels, to appropriate audiences, we ensure prompt leasing to well-matched tenants.  This offers potential tenants a wide, convenient and accessible choice, while landlords benefit from high visibility and prompt occupation.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">ONLINE SERVICES</a></h4>
                        <p>As a Trafalgar client, you are very welcome to use our online services to update your property management and account information. Simply log in using your pin and password, and gain access to a secure world of online property management information.</p>
                        <span class="read-more">
                            <a href="#">Click here</a>
                        </span>
                    </div>
                    
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <input type="text" required="" class="form-control" placeholder="Phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
