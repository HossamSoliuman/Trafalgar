<!DOCTYPE html>
<html>
<head>
    <title>500 error</title>
</head>
<body>
Some things went wrong 500 error.
</body>
</html>