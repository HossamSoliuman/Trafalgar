 <section class="main_footer">
        <div class="container">
            <div class="footerlogo_socialicon">
                <img class="footer_logo" src="{{ asset('front/images/logo.png')}}" alt="logo">
                <ul>
                    <li><a href="<?php if($setting->facebook_link){ echo $setting->facebook_link; }else{ echo "#"; } ?>"><img src="{{ asset('front/images/facebook.png')}}" alt=""></a></li>
                    <li><a href="<?php if($setting->instagram_link){ echo $setting->instagram_link; }else{ echo "#"; } ?>"><img src="{{ asset('front/images/insta.png')}}" alt=""></a></li>
                    <li><a href="<?php if($setting->twitter_link){ echo $setting->twitter_link; }else{ echo "#"; } ?>"><img src="{{ asset('front/images/twitter.png')}}" alt=""></a></li>
                    <li><a href="<?php if($setting->linkedin_link){ echo $setting->linkedin_link; }else{ echo "#"; } ?>"><img src="{{ asset('front/images/linked.png')}}" alt=""></a></li>
                    <li><a href="<?php if($setting->youtube_link){ echo $setting->youtube_link; }else{ echo "#"; } ?>"><img src="{{ asset('front/images/youtube.png')}}" alt=""></a></li>
                </ul>
            </div>
            <div class="row m-0">
                <div class="col-md-6 col-lg-3">
                    <div class="footer_main_content">
                        <h5>Quick Links</h5>
                        <div class="content_list">
                            <ul>
                                <li><a href="{{ url('/') }}">Home</a></li>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Agent Search</a></li>
                                <li><a href="#">Developer Services</a></li>
                                <li><a href="{{ url('/joblist') }}">Career Opportunities</a></li>
                                <li><a href="#">Blog</a></li>
                                <li><a href="#">Contact us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="footer_main_content">
                        <h5>I’M Interested In</h5>
                        <div class="content_list">
                            <ul>
                                <li><a href="#">Property to Rent</a></li>
                                <li><a href="#">Property Management Services</a></li>
                                <li><a href="#">Property Insurance</a></li>
                                <li><a href="#">Property Finance</a></li>
                                <li><a href="#">Making Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="footer_main_content">
                        <h5>Popular Property Search</h5>
                        <div class="content_list">
                            <ul>
                                <li><a href="#">Property to Rent by Area</a></li>
                                <li><a href="#">Property To Rent Cape Town</a></li>
                                <li><a href="#">Property To Rent Johannesburg</a></li>
                                <li><a href="#">Property to Rent Midrand</a></li>
                                <li><a href="#">Property To Rent Durban</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="footer_main_content">
                        <h5>General Info</h5>
                        <div class="content_list d-flex justify-content-between">
                            <ul>
                                <li><a href="#">Useful Links</a></li>
                                <li><a href="#">Trafalgar Property Management</a></li>
                                <li><a href="{{ route('disclaimer') }}">Disclaimer</a></li>
                                <li><a href="#">Agent Login</a></li>
                                <li><a href="{{ url('/front/pdf/Supplier-Privacy-Policy.pdf') }}" target="_blank">Supplier Privacy Policy</a></li>
                                <li><a href="#">Trafalgar financial Services</a></li>
                                <li><a href="{{ route('terms-conditions') }}">Terms Conditions</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>