@extends('layouts.front')

@section('content')
    
    <!-- breadcrumb section  -->
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">Useful Links</a></li>
          </ul>
      </div>
    </div>
    <!-- breadcrumb section  -->
    
    <!-- useful links page section  -->
    <section class="guldenland_section about_page_content mt-5">
        <div class="container">
            <div class="heading mb-4">
                <h2>Useful Links</h2>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing1">
                    <div class="manage-paragraph">
                        <h4>Associations:</h4>
                        <div class="links_list_view">
                            <div class="links_list">
                                <p>National Association of Managing Agents (NAMA):</p>
                                <a href="#">http://www.nama.org.za/</a>
                            </div>
                            <div class="links_list">
                                <p>Estate Agency Affairs Board (EAAB):</p>
                                <a href="#">http://www.eaab.org.za/</a>
                            </div>
                            <div class="links_list">
                                <p>CIA:</p>
                                <a href="#">http://cia.co.za/</a>
                            </div>
                            <div class="links_list">
                                <p>Johannesburg Property Owners and Managers Association (JPOMA):</p>
                                <a href="#">http://www.jpoma.co.za/</a>
                            </div>
                        </div>
                        
                        <h4>Social Media:</h4>
                        <div class="links_list_view">
                            <div class="links_list">
                                <p>Trafalgar Facebook page:</p>
                                <a href="#">https://www.facebook.com/Trafalgar.Property</a>
                            </div>
                            <div class="links_list">
                                <p>Trafalgar Twitter:</p>
                                <a href="#">https://twitter.com/TrafalgarPM</a>
                            </div>
                        </div>
                        
                        <h4>Partner Links:</h4>
                        <div class="links_list_view">
                            <div class="links_list">
                                <a href="#">www.sectionaltitlecentre.co.za</a>
                            </div>
                            <div class="links_list">
                                <a href="#">www.lessor.co.za</a>
                            </div>
                            <div class="links_list">
                                <a href="#">www.paddocks.co.za/advice/paddocks-club/</a>
                            </div>
                            <div class="links_list">
                                <a href="#">www.deeds.gov.za</a>
                            </div>
                            <div class="links_list">
                                <a href="#">club.paddocks.co.za</a>
                            </div>
                        </div>
                        
                        <h4>National City Council Websites:</h4>
                        <div class="links_list_view">
                            <div class="links_list">
                                <p>City of Joburg</p>
                                <a href="#">http://www.joburg.org.za/</a>
                            </div>
                            <div class="links_list">
                                <p>Tshwane City Council – Pretoria</p>
                                <a href="#">http://www.tshwane.gov.za/</a>
                            </div>
                            <div class="links_list">
                                <p>City of Cape Town</p>
                                <a href="#">http://www.capetown.gov.za/</a>
                            </div>
                            <div class="links_list">
                                <p>East London</p>
                                <a href="#">http://www.buffalocity.gov.za/</a>
                            </div>
                            <div class="links_list">
                                <p>Port Elizabeth</p>
                                <a href="#">http://www.nelsonmandelabay.gov.za/</a>
                            </div>
                            <div class="links_list">
                                <p>Durban</p>
                                <a href="#">http://www.durban.gov.za/Pages/default.aspx</a>
                            </div>
                        </div>
                        
                        <h4>Trafalgar Managed Complexes Or Estates:</h4>
                        <div class="links_list_view">
                            <div class="links_list">
                                <p>Valley View Estate</p>
                                <a href="#">http://valleyviewestatehoa.org.za/</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                        <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <label for="username">Name<span>*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                     <label for="email">Email<span>*</span></label>
                                     <input type="email" class="form-control" placeholder="Enter email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <label for="phone">Phone<span>*</span></label>
                                     <input type="text" required="" class="form-control" placeholder="Enter phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                   <label for="message">Message<span>*</span></label>
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Enter message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <label for="username">Name<span>*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group ">
                                     <label for="email">Email<span>*</span></label>
                                     <input type="email" class="form-control" placeholder="Enter email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- useful links page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
