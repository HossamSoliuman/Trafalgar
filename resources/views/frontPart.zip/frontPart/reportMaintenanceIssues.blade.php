@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Report Maintenance Issues</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            <div class="heading mb-4">
                <h2>Report Maintenance Issues</h2>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing">
                    <div class="maintenance_form_view">
                        <div class="maintenance_form">
                            <form>
                                <div class="maintenance_form_inner">
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="name">Name:<span>*</span></label>
                                            <input type="text" class="form-control" id="name">
                                        </div>
                                        <div class="form-group">
                                            <label for="building-name">Building name:<span>*</span></label>
                                            <input type="text" class="form-control" id="building-name">
                                        </div>
                                        <div class="form-group">
                                            <label for="unit-no">Unit Number:<span>*</span></label>
                                            <input type="text" class="form-control" id="unit-no">
                                        </div>
                                    </div>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="physical-address">Physical address:<span>*</span></label>
                                            <textarea type="text" class="form-control" id="physical-address" rows="2"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <h4>Contact Details:</h4>
                                <div class="maintenance_form_inner">
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="tel">Tel:<span>*</span></label>
                                            <input type="number" class="form-control" id="tel">
                                        </div>
                                        <div class="form-group">
                                            <label for="cell">Cell:<span>*</span></label>
                                            <input type="text" class="form-control" id="cell">
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email:<span>*</span></label>
                                            <input type="email" class="form-control" id="email">
                                        </div>
                                    </div>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="report-maintenance">Report maintenance:<span>*</span></label>
                                            <textarea type="text" class="form-control" id="report-maintenance" rows="2"></textarea>
                                        </div>
                                    </div>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label>Urgency (please tick one):<span>*</span></label>
                                            <div class="radio-group">
                                              <span>
                                                <input type="radio" id="critical" name="radio-group" checked="">
                                                <label for="critical">Critical (< 6 hours)</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="urgent" name="radio-group">
                                                <label for="urgent">Urgent (< 12 hours)</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="high" name="radio-group">
                                                <label for="high">High (24 - 48 hours)</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="low" name="radio-group">
                                                <label for="low">Low (5 working days)</label>
                                              </span>
                                            </div>
                                        </div>
                                    </div>
                                    <b class="my-3 d-block">Disclaimer: indicative timing is an objective resolution turn around time and dependent on contractor availability and the scope of work required.</b>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label>Person responsible for the account:<span>*</span></label>
                                            <div class="radio-group">
                                              <span>
                                                <input type="radio" id="hoa" name="radio-group" checked="">
                                                <label for="hoa">Body Corporate / HOA</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="owner" name="radio-group">
                                                <label for="owner">Owner</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="tenant" name="radio-group">
                                                <label for="tenant">Tenant</label>
                                              </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label>Quote first/approved job:<span>*</span></label>
                                            <div class="radio-group">
                                              <span>
                                                <input type="radio" id="quotation" name="radio-group" checked="">
                                                <label for="quotation">Quotation required</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="directly" name="radio-group">
                                                <label for="directly">Attend to work directly</label>
                                              </span>
                                            </div>
                                        </div>
                                    </div>
                                    <b class="my-3 d-block">Image Upload: Please resize images to 100 – 150kbs. The file max size limit is 1MB</b>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="upload-file">Upload file<span>*</span></label>
                                            <input type="file" class="form-control" id="upload-file" accept="image/png, image/jpeg">
                                        </div>
                                        <div class="form-group">
                                            <label for="upload-file">Upload file<span>*</span></label>
                                            <input type="file" class="form-control" id="upload-file" accept="image/png, image/jpeg">
                                        </div>
                                        <div class="form-group">
                                            <label for="upload-file">Upload file<span>*</span></label>
                                            <input type="file" class="form-control" id="upload-file" accept="image/png, image/jpeg">
                                        </div>
                                        <div class="form-group">
                                            <label for="upload-file">Upload file<span>*</span></label>
                                            <input type="file" class="form-control" id="upload-file" accept="image/png, image/jpeg">
                                        </div>
                                        <div class="form-group">
                                            <label for="upload-file">Upload file<span>*</span></label>
                                            <input type="file" class="form-control" id="upload-file" accept="image/png, image/jpeg">
                                        </div>
                                    </div>
                                    <button type="submit" class="form-control">Submit</button>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                  
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <input type="text" required="" class="form-control" placeholder="Phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
