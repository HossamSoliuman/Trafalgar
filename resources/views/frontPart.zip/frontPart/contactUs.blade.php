@extends('layouts.front')

@section('content')

<div class="breadcrumbs">
    <div class="container">
        <ul>
            <li><a href="#">Manage</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
</div>

<section class="contact_section">
    <div class="container">
        <div class="contact_content text-center">
            <h5>Our National Share Call Number is: 0861 66 44 44</h5>
            <h2>Branch Information</h2>
            <p class="m-0">For branch address and contact details please select the required regional branch:</p>
        </div>

        <div class="tabs_section">
            <div class="container">
                <div class="tab">

                    <div class="tab__list">
                        <div class="tab__item">Cape Town</div>
                        <div class="tab__item">Durban</div>
                        <div class="tab__item">East London</div>
                        <div class="tab__item">Johannesburg</div>
                        <div class="tab__item">Estate Offices</div>
                        <div class="tab__item">Knysna</div>
                        <div class="tab__item">Port Elizabeth</div>
                        <div class="tab__item">Pretoria</div>
                        <div class="tab__item">Trafalgar Financial Services</div>
                    </div>

                    <div class="tab__content">
                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Regional Head</div>
                                <div class="tab__item">Office Winelands</div>
                                <div class="tab__item">Table View</div>
                            </div>
                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>ct@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Unit 12 M5 PARK Eastman Road <br /> Maitland Cape Town
                                                        7405</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 2847 Cape Town 8000</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>021 410 5500</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>071 204 7492</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>S 33.92911º</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>E 018.48054º</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13241.713663443321!2d18.4809944!3d-33.9301077!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7309076fedc2ac08!2sM5%20Park!5e0!3m2!1sen!2sin!4v1647924986292!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head wineland">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>stb@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>20 on Krige Krige Street <br /> Stellenbosch 7600</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 2847 Cape Town 8000</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>021 882 8686</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>071 204 7492</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>-33.940052 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>18.856677 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13240.17355551827!2d18.85652225252034!3d-33.94001213464686!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1647925073643!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head table-view">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>tableview@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>169 Blaauwberg Road Table View <br /> Cape Town 7441</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>169 Blaauwberg Road Table View <br /> Cape Town 7441</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>021 556 2780</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>071 204 7492</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>-33.827420 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>18.500270 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13257.626143499996!2d18.50019762214043!3d-33.82762509329675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1647925111238!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Regional Head</div>
                                <div class="tab__item">Ballito</div>
                            </div>

                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>durban@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>141 K E Masinga (Old Fort) Road <br /> Durban 4001</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 3964 Durban 4000</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>031 301 7017</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>061 336 9581</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>29.852228 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>31.023540 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3460.4176109634373!2d31.021351315110607!3d-29.852227981952606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1ef7a9cf0cb959f9%3A0xb0139966d8e8e8f1!2s141%20KE%20Masinga%20Rd%2C%20Durban%20Central%2C%20Durban%2C%204001%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925145881!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head ballito">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>sasham@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Izulu Office Park Rey’s Place <br /> Ballito Office A101
                                                        4399</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 3964 Durban 4000</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>087 354 9035</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>061 336 9581</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>-29.528721 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>31.203883 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13886.303228404446!2d31.2038828!3d-29.5287213!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1af882b8c5718665!2sIzulu%20Office%20Park!5e0!3m2!1sen!2sin!4v1647925172926!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Regional Head</div>
                                <div class="tab__item">Gonubie</div>
                            </div>

                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>el@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Shop 11, The New Colonnade Devereux Avenue Vincent
                                                        5247</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 19622 Tecoma 5214</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>043 726 6066</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>078 819 7026</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>32.984692 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>27.904071 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3346.7174537798032!2d27.902240515187316!3d-32.98485548090973!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e66e039cb2f539d%3A0xe1dc033066544545!2s37%20Devereux%20Ave%2C%20Berea%2C%20East%20London%2C%205241%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925194946!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head gonubie">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>elreception@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Shop 3 The Schwedhelp Building <br /> 35 Main Road Gonubie
                                                        5257</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 19622 Tecoma 5214</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>043 912 0100</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>083 267 5317</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>-32.961730 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>27.915580 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13393.921059049802!2d28.0108628!3d-32.9383274!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e671f51c53ea473%3A0x72c22daceb47aa24!2s35%20Main%20Rd%2C%20Gonubie%20North%2C%20Gonubie%2C%205257%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925215742!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Regional Head</div>
                                <div class="tab__item">Inner City</div>
                            </div>

                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>jhb@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>74 St Andrew Street <br /> Birdhaven 2196</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 782813 Sandton 2146</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>011 214 5200</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>083 460 9777</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>26.136975 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>28.058186 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3581.8245234141345!2d28.056098615028656!3d-26.137263883467675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950ce41526fa89%3A0x3abac678ca5c6ab9!2s74%20St%20Andrew%20St%2C%20Birdhaven%2C%20Johannesburg%2C%202196%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925234717!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head innercity">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>allysonk@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>30 Joel Road Berea <br /> Johannesburg 2198</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 17227 Hillbrow 2038</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>011 544 3900</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>071 881 1784</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>26.187360 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>28.053150 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3580.286404848228!2d28.050961315029564!3d-26.187359983445372!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950c256651b301%3A0xa44730fb077b78b8!2s30%20Joel%20Rd%2C%20Berea%2C%20Johannesburg%2C%202198%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925255529!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Dainfern</div>
                                <div class="tab__item">The Hills</div>
                                <div class="tab__item">Waterfall Country Estate</div>
                                <div class="tab__item">Waterfall Country Village</div>
                                <div class="tab__item">Waterfall Hills Mature Lifestyle Estate</div>
                            </div>

                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head dainfern">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>dainfern@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Dainfern Homeowners Association 633 Gateside Avenue Dainfern 2050</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>C/O Trafalgar Property Management <br /> PO Box 782813 Sandton
                                                        2146</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>011 875 0401</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>27.987041”S</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>-25.988202E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3586.378125394097!2d27.99519631502564!3d-25.98842808353434!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x142bce906a4d07b%3A0xa9d97070cc16b206!2sDainfern%20Golf%20%26%20Residential%20Estate!5e0!3m2!1sen!2sin!4v1647925282073!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head hills">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>thehills@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>The Hills Garsfontein Road <br /> Pretoria 0002</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>C/O Trafalgar Property Management <br /> PO Box 782813 Sandton
                                                        2146</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>071 674 3095</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>28.36002”S</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>-25.872176E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3589.933120802138!2d28.3581987150233!3d-25.87167848358702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e955ccd2c903dad%3A0x3c29269ae683be94!2sPotentiality!5e0!3m2!1sen!2sin!4v1647925320443!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head country-estate">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>waterfall@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Waterfall Country Estate Maxwell Drive Jukskei View Ext 19 Midrand 1685</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>C/O Trafalgar Property Management <br /> PO Box 782813 Sandton
                                                        2146</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>010 591 4671 / 4950</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>26.01’29,76”S</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>28.05’30.10E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14341.796808563158!2d28.0941099!3d-26.0188545!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e957218fbce76d7%3A0x5c983f852f1776f!2sWaterfall%20Country%20Estate%20-%20North!5e0!3m2!1sen!2sin!4v1647925345622!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head country-village">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>waterfall@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Waterfall Country Estate Maxwell Drive Jukskei View Ext 53 Midrand 1685</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>C/O Trafalgar Property Management <br /> PO Box 782813 Sandton
                                                        2146</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>010 591 4671 / 4950</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>26,00’49.80”S</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>28.05’45.05E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3585.6209926417773!2d28.09361981502617!3d-26.01323008352328!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e9571f6140bfef9%3A0xa54c9d9221fb9b27!2sGate%204%20Waterfall%20Country%20Village!5e0!3m2!1sen!2sin!4v1647925360589!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head lifestyle-estate">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>shauns@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>Waterfall Country Estate Waterfall Hills 2 <br /> Waterfall
                                                        Lane Sunninghill 2191</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>C/O Trafalgar Property Management <br /> PO Box 782813 Sandton
                                                        2146</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>011 260 6800</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>26,01’10.8552”S</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>28.05’19.2336E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3585.2330991596323!2d28.0840156!3d-26.0259281!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e9572236eb54885%3A0x6bc5a5b981062ba4!2sWaterfall%20Hills%20Mature%20lifestyle%20Estate!5e0!3m2!1sen!2sin!4v1647925394979!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Regional Head</div>
                            </div>

                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>knysna@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>No. 5 Pledge Square 48 Main Street <br /> Knysna 6571</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 373 Knysna 6570</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>044 382 6230</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Fax:</span>
                                                    <span>044 382 6450</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>-34.03954°</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>23.04448</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3306.369565389473!2d23.04227131521456!3d-34.034389980610804!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e78ea891f7432d5%3A0x2090b7318de7c5b4!2s48%20Main%20Rd%2C%20Rexford%2C%20Knysna%2C%206571%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925409468!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Regional Head</div>
                                <div class="tab__item">Port Elizabeth Central</div>
                                <div class="tab__item">Jeffrey's Bay</div>
                            </div>

                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>pe@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>2 Ascot Road Mill Park <br /> Port Elizabeth 6001</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 34823 Newton Park 6055</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>041 365 6840</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>063 511 8554</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>-33.955150 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>25.5883 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3309.458272520207!2d25.5886793!3d-33.9550588!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e7ad23685a3dddb%3A0x24ed4b1f2bfabfdf!2s2%20Ascot%20Rd%2C%20Mill%20Park%2C%20Gqeberha%2C%206001%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925433121!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head elizabeth-central">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>peletting@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>2 Parliament Street Central <br /> Port Elizabeth 6001</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>2 Parliament Street Central <br /> Port Elizabeth 6001</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>041 125 0150/2</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Cell:</span>
                                                    <span>061 501 5110</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>063 511 8554</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>33.961968 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>25.614083 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13236.79399132782!2d25.61688882243363!3d-33.96173720215031!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1647925466624!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab__content-item">
                                    <div class="addresses_head jeffrey-bay">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>kellyh@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>17 Da Gama Road <br /> Jeffreys Bay 6330</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>17 Da Gama Road <br /> Jeffreys Bay 6330</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>041 365 6840</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>063 5118 554</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>-34.054540 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>24.922800 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13222.365888150556!2d24.9225991!3d-34.0543491!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e7af8b497937ab9%3A0x569124b201afca8a!2s17%20Da%20Gama%20Rd%2C%20Jeffreys%20Bay%2C%206330%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925490686!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="tab__content-item tab">
                            <div class="tab__list">
                                <div class="tab__item">Regional Head</div>
                            </div>

                            <div class="tab__content">
                                <div class="tab__content-item">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>pta@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>829 Stanza Bopape Street <br /> Arcadia 0083</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 14122 Hatfield <br /> Pretoria 0028</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>012 326 5963</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>083 399 9930</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>25.744590 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>28.221302 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14375.201722721287!2d28.22122636619208!3d-25.74411250151264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1647925521388!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab__content-item">
                            <div class="tab__content">
                                <div class="tab__content-item1">
                                    <div class="addresses_head regional">
                                        <div class="addresses">
                                            <div class="each_address">
                                                <span class="icon-envelope contact-icons"></span>
                                                <p>
                                                    <span>Email Address:</span>
                                                    <span>tfs@trafalgar.co.za</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Physical Address:</span>
                                                    <span>74 St Andrew Street <br /> Birdhaven 2196</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-home contact-icons"></span>
                                                <p>
                                                    <span>Postal Address:</span>
                                                    <span>P.O. Box 782813 <br /> Sandton 2146</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Tel:</span>
                                                    <span>011 214 5200</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-phone contact-icons"></span>
                                                <p>
                                                    <span>Afterhours emergencies:</span>
                                                    <span>072 972 0812</span>
                                                </p>
                                            </div>
                                            <div class="each_address">
                                                <span class="icon-map contact-icons"></span>
                                                <p>
                                                    <span>Latitude:</span>
                                                    <span>26.136975 N</span>
                                                </p>
                                                <br />
                                                <p>
                                                    <span>Longitude:</span>
                                                    <span>28.058186 E</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div id="address_map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3581.8245234141345!2d28.056098615028656!3d-26.137263883467675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950ce41526fa89%3A0x3abac678ca5c6ab9!2s74%20St%20Andrew%20St%2C%20Birdhaven%2C%20Johannesburg%2C%202196%2C%20South%20Africa!5e0!3m2!1sen!2sin!4v1647925544646!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    </div>

    <div class="maintenance_form_view">
        <div class="management_form">
            <h2>Contact Us</h2>
            <form>
                <div class="maintenance_form_inner">
                    <div class="field_row">
                        <div class="form-group">
                            <label for="name">Name<span>*</span></label>
                            <input type="text" class="form-control" id="name">
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label for="email">Email:<span>*</span></label>
                            <input type="email" class="form-control" id="email">
                        </div>
                        <div class="form-group">
                            <label for="cellphone">phone:<span>*</span></label>
                            <input type="number" class="form-control" id="cellphone">
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label for="city">City:<span>*</span></label>
                            <input type="text" class="form-control" id="city">
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label>Preferred method of contact<span>*</span></label>
                            <div class="radio-group">
                                <span>
                                    <input type="radio" id="p_phone" name="radio-group">
                                    <label for="p_phone">Phone</label>
                                </span>
                                <span>
                                    <input type="radio" id="p_email" name="radio-group">
                                    <label for="p_email">Email</label>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="scheme">Preferred time to be called<span>*</span></label>
                            <input type="text" class="form-control" id="scheme">
                        </div>
                    </div>
                    <div class="field_row">
                        <div class="form-group">
                            <label for="comments">Comments or Questions</label>
                            <textarea type="text" class="form-control" id="comments" rows="3"></textarea>
                        </div>
                    </div>
                    <button type="submit" class="m-0 form-control">Send message</button>
                </div>

            </form>
        </div>
    </div>
    </div>
</section>


<!-- page section  -->

<!-- main footer section  -->

@include('frontPart/mainFooter')

<!-- main footer section  -->

<!-- copyright section  -->
@endsection