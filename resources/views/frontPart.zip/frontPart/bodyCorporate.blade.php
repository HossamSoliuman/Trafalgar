@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Body Corporate, HOA And Share Block Loans</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            <div class="heading mb-4">
                <h2>Body Corporate, HOA And Share Block Loans</h2>
                 <div class="manage-paragraph text-justify">
                    <p>Typically speaking, bodies corporate, Home Owners Associations (HOA’s) and share block companies budget for, and accumulate, surpluses for large maintenance projects either in the ordinary budget or via special levy over term (which can be anywhere up to five years). Too often these monies are absorbed into the monthly operational costs of the body corporate / HOA or get diverted into alternate projects for which they were never (initially) intended. Further, the Act is quite restrictive in terms of where surplus monies can be invested (PMR41, PMR42 and PMR43) arguably heightening the opportunity cost of this method of fund accumulation (said legislation applicable to bodies corporate while the MOI of the HOA would govern same); sector inflation being unknown, and not reported on by STATS SA, also means that the project cost is, in essence, a moving target further complicating the process of raising monies for related maintenance or capital project(s).</p>
                </div>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing1">
                    <div class="manage-paragraph">
                        <p><b>Trafalgar Financial Services</b> offers upfront finance for maintenance and capital projects on favourable terms tailor made to fit the cash flow constraints of the borrower (body corporate, HOA or share block company). More importantly, this allows for the immediate restoration or enhancement of value, on definite terms, removing any uncertainties involved with the process or project.</p>
                        <p>Finance in action – Have a look at a few of our case studies:</p>
                        <div class="pdf_list">
                            <a href="https://www.trafalgar.co.za/wp-content/uploads/2016/09/Elizabeth-Court.pdf" target="_blank"> <span class="icon-file-pdf-o mr-2"></span> Elizabeth Court</a>
                            <a href="https://www.trafalgar.co.za/wp-content/uploads/2016/09/Kingfisher-Close.pdf" target="_blank"> <span class="icon-file-pdf-o mr-2"></span> Kingfisher Close</a>
                            <a href="https://www.trafalgar.co.za/wp-content/uploads/2016/09/Meadowfields.pdf" target="_blank"> <span class="icon-file-pdf-o mr-2"></span> Meadowfields</a>
                            <a href="https://www.trafalgar.co.za/wp-content/uploads/2016/09/Rydal-Mount.pdf" target="_blank"> <span class="icon-file-pdf-o mr-2"></span> Rydal Mount</a>
                        </div>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <input type="text" required="" class="form-control" placeholder="Phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
