@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Developer Services</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            <div class="heading mb-4">
                <h2>Developer Services</h2>
                <div class="manage-paragraph text-justify">
                    <p>Trafalgar offers a comprehensive range of advisory and support services for residential and sectional title property developers and their professional teams. Property management input is recommended from an early design stage of a new development and sectional title scheme. Based on signing a management agreement, the advisory services listed below are provided free of charge to assist with setting up the development and sectional title building in an effective and legally compliant manner.</p>
                </div>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing">
                    <div class="manage-paragraph paragraph-listing">
                        <p>Trafalgar’s sectional title, property management and advisory services for residential property developers comprises:</p>
                        <ul>
                            <li>Design input to promote property and facility management effectiveness</li>
                            <li>Levy budget formulation to assist with property sales</li>
                            <li>Conduct rule recommendations</li>
                            <li>Collection of quotes from preferred service providers for security, cleaning, gardening as required</li>
                            <li>Estate management</li>
                            <li>Assisting with occupation logistics</li>
                            <li>Facilitation of the inaugural AGM</li>
                            <li>Assistance with the developer’s reconciliation to present at the AGM to recover costs</li>
                            <li>Activation of legally compliant property management processes and reporting</li>
                            <li>Trustee training</li>
                        </ul>
                        <p>All Trafalgar’s sectional title and property management services can be tailored and customised to specific property and developer requirements. To obtain further information, please contact Andrew Schaefer on <a href="mailto:andrews@trafalgar.co.za">andrews@trafalgar.co.za</a> or 011 214 5200</p>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <input type="text" required="" class="form-control" placeholder="Phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
