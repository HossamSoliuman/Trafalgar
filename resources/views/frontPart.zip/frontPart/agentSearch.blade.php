@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Agent Search</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing1">
                  
                    
                    @if(!empty($arrayResidential))
                    
                    <div class="heading mb-0">
                       <h3 style="font-weight:500" class="mb-0">Residential Agents</h3>
                    </div>
                    
                    @foreach($arrayResidential as $agentTownKey => $agentTownValue)
                    <div class="d-flex flex-column gap-20">
                        <h6>{{ strtoupper($agentTownKey) }}</h6>
                        @if(!empty($agentTownValue))
                        <div class="all_agents">
                           
                            @foreach($agentTownValue as $agentDetail)
                            <div class="eachagent_view">
                                <img class="img-fluid" src="{{ $agentDetail['photo_url'] }}">
                                <div class="agent_name_contact">
                                    <a href="{{ route('agent',['agentid'=> $agentDetail['agent_id']]) }}"><h6>{{$agentDetail['agent_name'] }}</h4></a>
                                    @if(isset($agentDetail['mobile_number']))
                                     <p class="mobileshow" data-attr="{{ str_replace(' ','-',$agentTownKey) }}{{ $loop->iteration }}" style="cursor:pointer;"><span class="icon-phone"></span>Show Contact Number</p>
                                    <p id="mobileshow{{ str_replace(' ','-',$agentTownKey) }}{{ $loop->iteration }}" style="display:none;"><span class="icon-phone"></span>{{ $agentDetail['mobile_number'] }}</p>
                                    @endif
                                    
                                    <a class="readmore" href="{{ route('agent',['agentid'=> $agentDetail['agent_id']]) }}">Read More ></a>
                                </div>
                            </div>
                            
                            @endforeach
                        </div>
                        @endif
                    </div>
                     @endforeach
                    
                    @endif
                    
                    @if(!empty($arrayCommercial))
                    
                    <div class="heading mb-0">
                       <h3 style="font-weight:500" class="mb-0">Commercial Agents</h3>
                    </div>
                    
                    @foreach($arrayCommercial as $agentTownKey => $agentTownValue)
                    <div class="d-flex flex-column gap-20">
                        <h6>{{ strtoupper($agentTownKey) }}</h6>
                        @if(!empty($agentTownValue))
                        <div class="all_agents">
                            @foreach($agentTownValue as $agentDetail)
                            <div class="eachagent_view">
                                <img class="img-fluid" src="{{ $agentDetail['photo_url'] }}">
                                <div class="agent_name_contact">
                                    <a href="#"><h6>{{ $agentDetail['agent_name'] }}</h4></a>
                                    <p class="mobileshow"><span class="icon-phone"></span>Show Contact Detail</p>
                                    <a class="readmore" href="#">Read More ></a>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        @endif
                    </div>
                     @endforeach
                    
                    @endif
                   
                    
                    
                </div>
                <div class="guldenland_sidebar">
                    <div class="contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="{{ route('quick-contact') }}" method="post">
                            @csrf                 
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <label for="username">Name<span>*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter name" required="" id="name" name="name">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                     <label for="email">Email<span>*</span></label>
                                     <input type="email" class="form-control" placeholder="Enter email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <label for="phone">Phone<span>*</span></label>
                                     <input type="text" required="" class="form-control" placeholder="Enter phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                   <label for="message">Message<span>*</span></label>
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Enter message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                              <div class="col-12">
                                  <p class="term-policy">
                                      By continuing I understand and agree with Trafalgar <a href="https://webplan.live/terms-conditions">Terms &amp; Conditions</a> and <a href="https://webplan.live/front/pdf/Supplier-Privacy-Policy.pdf">Privacy Policy</a>.
                                  </p>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="property_alert">
                        <div class="e-magazine-right-content">
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="https://webplan.live/front/images/alert.png" alt="">
                                </div>
                                <div class="magazine-content">
                                    <h4>Property Alerts</h4>
                                    <p>Sign up for your customised property alerts delivered
                                        directly to your inbox.</p>
                                </div>
                            </div>
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="https://webplan.live/front/images/property.png" alt="">
                                </div>
                                <div class="magazine-content">
                                    <h4>List Your Property</h4>
                                    <p>List to sell your property with the help of our qualified
                                        real estate professionals.</p>
                                </div>
                            </div>
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="https://webplan.live/front/images/valuation.png" alt="">
                                </div>
                                <div class="magazine-content">
                                    <h4>Free Valution</h4>
                                    <p class="mb-0">Request a free property valuation from one of our real
                                        estate agents to find out what your property is worth.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

   @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection

@push('agent-search-js-page')
@include('frontPart.js.agentSearchJs')
@endpush

