@extends('layouts.front')

@section('content')
    
    <!--about banner-->
    <section class="jobbanner-section service_top_banner">
        <div class="jobbanner-text">
            <h1 class="m-0">Online Services</h1>
        </div>
    </section>
    <!--about banner-->
    
    <!-- about page section  -->
    <section class="service_page_content my-5">
        <div class="container">
            <div class="heading">
                <!--<h2>About Us</h2>-->
                <div class="manage-paragraph text-justify">
                    <p>As a Trafalgar client, you are very welcome to use our online services, which are comprised of:</p>
                </div>
            </div>
            <div class="property-solution online_services_view">
                <div class="container">
                    <div class="online_services_ mt-4">
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img class="img-fluid" src="https://webplan.live/front/images/online-account.svg" alt="">
                            </div>
                            <h5>Online Accounts</h5>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/online-application.svg" alt="">
                            </div>
                            <h5>Online Application</h5>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/registration.svg" alt="">
                            </div>
                            <h5>Registration Certificates</h5>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/maintenance.svg" alt="">
                            </div>
                            <h5>Report Maintenance Issues</h5>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/portal.svg" alt="">
                            </div>
                            <h5>Property Portal</h5>
                            <button class="theme-btn">Read More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
