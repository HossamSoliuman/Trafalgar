@extends('layouts.front')

@section('content')

<section class="profile_section_view">
    <div class="container">
        <div class="profile_content_">
            <div class="profile_view">
                <div class="profile_img">
                    <img class="img-fluid" src="https://s3-eu-west-1.amazonaws.com/etoms/U_2020_08_06_13_11_17_986.jpg" />
                </div>
                <div class="profile_content">
                    <h4 class="">User Name</h4>
                    <small><span class="icon-map"></span> SAN FRANCISCO, CA</small>
                    <div class="agent_social_network">
                        <ul>
                            <li>
                                <span class="icon-phone"></span> <a href="tel:123456789">1234567890</a>
                            </li>
                            <li>
                                <span class="icon-envelope"></span> <a href="mailto:adelev@trafalgar.co.za">example@trafalgar.co.za</a>
                            </li>
                            <li>
                                <span class="icon-whatsapp"></span> <a href="#">Whatsapp Agent</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <small class="mt-3 d-block">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </small>
            <div class="line"></div>
        </div>
        <div class="wrapper">
            <!-- Sidebar  -->
            <nav id="sidebar">
                <ul class="list-unstyled components">
                    <!--<p>User Profile</p>-->
                    <li class="active">
                        <a href="#">Change Password</a>
                    </li>
                    <li>
                        <a href="#">Favorites</a>
                    </li>
                    <li>
                        <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Others</a>
                        <ul class="collapse list-unstyled" id="pageSubmenu">
                            <li>
                                <a href="#">Page 1</a>
                            </li>
                            <li>
                                <a href="#">Page 2</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
    
            <!-- Page Content  -->
            <div id="content">
                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <span class="icon-menu"></span>
                </button>
                <div class="profile-form auth_forms_view py-0 border-0">
                    <form method="POST" action=""> 
                        <div class="row mb-2">
                            <div class="col-md-6 mb-2">
                            <label for="o-password">Old Password</label>
                                <input id="o-password" type="password" class="form-control " name="o-password" >
                            </div>
                            <div class="col-md-6 mb-2">
                            <label for="n-password">New Password</label>
                                <input id="n-password" type="password" class="form-control " name="n-password" >
                            </div>
                            <div class="col-md-12 d-flex justify-content-between align-items-end flex-column">
                                <button type="submit" class="btn submit_button w-25 mb-0">update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- main footer section  -->

@include('frontPart/mainFooter')

<!-- main footer section  -->

<!-- copyright section  -->
@endsection