  <section class="property-solution section-padding">
        <div class="container">
            <div class="heading text-center">
                <h1>One-stop Property Solutions </h1>
            </div>
            <div class="row mt-5">
                
                @if($propertySolutions)
                @foreach($propertySolutions as $propertySolution)
                <div class="col-12 col-md-6 col-lg-3 mb-lg-0 mb-3">
                    <div class="each-property-solution">
                        <div class="eachimg">
                            <img src="{{ asset('storage/property_soultion/'.$propertySolution->image_link) }}" alt="">
                        </div>
                        <h5>{{ $propertySolution->title_name }}</h5>
                        <p>{!! $propertySolution->description !!}</p>
                        <button class="theme-btn">Use us Now!</button>
                    </div>
                </div>
                @endforeach
                @endif
                <!--<div class="col-12 col-md-6 col-lg-3 mb-lg-0 mb-3">-->
                <!--    <div class="each-property-solution">-->
                <!--        <div class="eachimg">-->
                <!--            <img src="{{ asset('front/images/management.png')}}" alt="">-->
                <!--        </div>-->
                <!--        <h5>Sectional Title & HOA Management</h5>-->
                <!--        <p>Full-service property management services</p>-->
                <!--        <button class="theme-btn">Manage Now!</button>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-12 col-md-6 col-lg-3 mb-lg-0 mb-3">-->
                <!--    <div class="each-property-solution">-->
                <!--        <div class="eachimg">-->
                <!--            <img src="{{ asset('front/images/property-management.png')}}" alt="">-->
                <!--        </div>-->
                <!--        <h5>Commercial Property Management</h5>-->
                <!--        <p>Commercial landlord services, budgeting, reports & more</p>-->
                <!--        <button class="theme-btn">Manage Now!</button>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-12 col-md-6 col-lg-3 mb-lg-0 mb-3">-->
                <!--    <div class="each-property-solution">-->
                <!--        <div class="eachimg">-->
                <!--            <img src="{{ asset('front/images/finance-service.png')}}" alt="">-->
                <!--        </div>-->
                <!--        <h5>Property Finance Services</h5>-->
                <!--        <p>Body Corporate Loans, Levy Finance and more</p>-->
                <!--        <button class="theme-btn">Finance Now!</button>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </section>