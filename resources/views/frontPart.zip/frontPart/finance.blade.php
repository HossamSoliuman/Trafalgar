@extends('layouts.front')

@section('content')
    
    <!--about banner-->
    <section class="jobbanner-section finance_top_banner">
        <div class="jobbanner-text">
            <h1>Finance</h1>
        </div>
    </section>
    <!--about banner-->
    
    <!-- about page section  -->
    <section class="guldenland_section about_page_content mt-5">
        <div class="container">
            <div class="heading">
                <div class="manage-paragraph text-justify">
                    <p>Trafalgar Financial Services (“TFS”) is an authorised financial services and credit provider with a specialist property finance focus for all juristic, residential entities including, but not limited to, sectional title bodies corporate, non-profit home owners’ associations, share block companies and property owning entities). With a loan book in excess of R100 million, Trafalgar Financial Services is one of the largest, niche financiers, of residential properties in South Africa.</p>
                </div>
            </div>
            <div class="property-solution online_services_view mb-4">
                <div class="container">
                    <div class="online_services_ mt-4">
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img class="img-fluid" src="https://webplan.live/front/images/loan.svg" alt="">
                            </div>
                            <h5>Body Corporate Loans</h5>
                            <p>Short term finance for maintenance projects or other building requirements</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/finance.svg" alt="">
                            </div>
                            <h5>Levy Finance</h5>
                            <p>Eliminate the cash flow pressures of late or arrear levy payments</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/trafex.svg" alt="">
                            </div>
                            <h5>Trafex</h5>
                            <p>Safeguard against unexpected and unpleasant insurance excesses</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/contact.svg" alt="">
                            </div>
                            <h5>Contact Us</h5>
                            <p>Contact us direct for a broker to be in touch with you</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/owners.svg" alt="">
                            </div>
                            <h5>Finance For Residential Owners</h5>
                            <p>Loan finance for property investors wanting to refurbish their properties to increase rentals and reduce vacancies</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing">
                    <div class="each_manage_section">
                        <h4><a href="#">BODY CORPORATE, HOA AND SHARE BLOCK LOANS</a></h4>
                        <p>Typically speaking, bodies corporate, Home Owners Associations (HOA’s) and share block companies budget for, and accumulate, surpluses for large maintenance projects either in the ordinary budget or via special levy over term (which can be anywhere up to five years).</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">LEVY FINANCE</a></h4>
                        <p>Bodies corporate, home owners’ associations and share block companies are all too frequently held to ransom by some owners who default on their levy payments, resulting in cash flow problems.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">TRAFEX – EXCESS WAIVER AND SHORTFALL COVER</a></h4>
                        <p>Insurance excesses and policy limits are both well-established norms in the insurance industry; excesses specifically, are often the first things adjusted (upwards) by insurers to address increasing loss ratios and, given owners are typically liable for excesses [PMR 29(4)], do you have the means to settle both the excess and potential shortfall unannounced and without warning?</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section text-center">
                        <a class="mb-1 d-block" style="color:#6e0d16;" href="#">Click here to contact Trafalgar Financial Services</a>
                        <p class="mb-1">Trafalgar Financial Services (TFS) after hours number for claims (this number is specifically for clients insured through TFS).</p>
                        <p class="mb-1">AFTER HOURS CLAIMS NO. FOR EXTREME EMERGENCIES: <b>072 972 0812</b></p>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist">
                        <h4>Registration Certificates For Trafalgar Property Management (Pty) Ltd</h4>
                        <ul>
                            <li><a href="#">Estate Agency Affairs Board (EAAB) Certificate</a></li>
                            <li><a href="#">National Association of Managing Agents (NAMA) Certificate</a></li>
                            <li><a href="#">Council for Debt Collectors</a></li>
                            <li><a href="#">Professional Indemnity Cover</a></li>
                            <li><a href="#">South African Property Owners Association (SAPOA) Certificate</a></li>
                        </ul>
                    </div>
                    <div class="sidelist">
                        <h4>Registration certificates for Trafalgar Financial Services (Pty) Ltd</h4>
                        <ul>
                            <li><a href="#">Financial Services Board</a></li>
                            <li><a href="#">Registered Credit Provider</a></li>
                            <li><a href="#">FIA Membership Certificate</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- about page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
