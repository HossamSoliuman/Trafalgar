<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppliedJob extends Model
{
    use HasFactory;
    
    public function job()
    {
        return $this->belongsTo(Job::class);
    }
    
    public function appliedJobDocument()
    {
        return $this->hasMany(AppliedJobDocument::class);
    }

    public function appliedJobUserQualification()
    {
        return $this->hasMany(AppliedJobUserQualification::class);
    }
}
