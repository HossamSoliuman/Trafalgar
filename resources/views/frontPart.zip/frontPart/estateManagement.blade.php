@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Estate Management</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            <div class="heading mb-4">
                <h2>Estate Management</h2>
                 <div class="manage-paragraph text-justify">
                    <p>Trafalgar offers Estate Management Services to support Boards of Directors to achieve their requirements on site for facility management, soft services (cleaning, security, grounds maintenance, refuse removal), building site inspections, architectural guideline enforcement and compliance with the rules of the Estate. Complementing the back-office financial and administration service overseen by a designated portfolio manager, Estate Managers make a direct and important impact on the visual presentation and lifestyle at the Estate and hence play a crucial role in the overall property management service.</p>
                    <p>Depending on scale, budgets and service scope requirements, Trafalgar also offers part-time Estate Managers which cover a comparable service scope on a part-time basis, typically supporting smaller Estates or where budgetary constraints limit a full time resource.</p>
                    <p>Trafalgar’s Estate Management services are currently deployed at many high profile Estates across South Africa including Waterfall, Blue Valley Golf Estate, Selborne Golf Estate and Dainfern and comprise the following service elements:</p>
                </div>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing1">
                    <div class="manage-paragraph">
                        <b>Facility management:</b>
                        <p>Daily inspections and management of common area facilities (clubhouses, tennis courts, swimming pools).</p>
                        <b>Soft services:</b>
                        <p>Managing the service level agreements and service effectiveness of cleaning, security, refuse removal and grounds maintenance service providers working at the Estate.</p>
                        <b>Building site inspections:</b>
                        <p>Regular inspections as required of building sites for compliance with the Estate’s building rules. Collecting and managing building deposits is covered by Trafalgar’s billing, collections and accounting systems.</p>
                        <b>Architectural guidelines:</b>
                        <p>Supported by a professional architect, Trafalgar is equipped to support the enforcement and monitoring of defined architectural guidelines for an Estate.</p>
                        <b>Enforcement of the rules:</b>
                        <p>Surveillance and enforcement of the Estate Rules is very important for promoting an harmonious communal lifestyle. Estate Managers and their on-site teams play an important role with the visibility and enforcement of the rules for the benefit of all residents</p>
                        <b>Maintenance planning:</b>
                        <p>Trafalgar is equipped to develop and manage rolling 5 year maintenance plans and forecasts</p>
                        <b>Trafalgar’s Estate Management service:</b>
                        <p>Seamlessly interfaces with the back-office property management functions of billing, collections, debt collection, financial management and reporting which collectively promotes the long term success of an Estate both from a financial investment point of view as well as lifestyle benefit.</p>
                        <p>Trafalgar’s Estate Management services can be easily tailored to specific property contexts and challenges. For further information please contact Andrew Schaefer on 011 214 5200, 083 399 9907 or <a href="mailto:andrews@trafalgar.co.za">andrews@trafalgar.co.za</a>. Alternatively, please complete your details on the page link: <a href="https://www.trafalgar.co.za/contact-us/">https://www.trafalgar.co.za/contact-us/online-query/</a> and we will make contact with you right away.</p>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <input type="text" required="" class="form-control" placeholder="Phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
