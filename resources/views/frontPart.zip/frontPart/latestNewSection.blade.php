@if(isset($getNewsApi) && !empty($getNewsApi))
<section class="latest-news-section section-padding">
        <div class="container">
            <div class="heading text-center">
                <h1>Latest News</h1>
            </div>
            <div class="row mt-5">
                @foreach($getNewsApi as $getNewsApis)
                
                <div class="col-12 col-lg-4 text-center mb-lg-0 mb-3">
                    <div class="news-image">
                        <img class="img-fluid" src="{{ $getNewsApis['photo'] }}" alt="">
                        <div class="news-date">
                            <h3>
                               {{ date('d', strtotime($getNewsApis['post_date'])) }}
                               
                            </h3>
                            <h5>
                                {{ date('M', strtotime($getNewsApis['post_date'])) }}
                                
                                 </h5>
                        </div>
                    </div>
                    <div class="news-content text-center">
                        <h5>{{ $getNewsApis['title'] }}</h5>
                       
                      <?php $strReplace = str_replace("Read More","",$getNewsApis['info']); ?>
                      
                      <?php $strReplace = str_replace("&hellip;","",$strReplace); ?>
                      <?php $strReplace = str_replace("&raquo;","",$strReplace); ?>
                      <!--Str::limit($strReplace, 250, $end='.......')-->
                        <p>{!! $strReplace !!}</p>
                                
                        <a target="_blank" class="d-flex align-items-center justify-content-center" href="{{ $getNewsApis['url'] }}">Read More
                            <span class="arrow-right"><img class="img-fluid" src="{{ asset('front/images/right-arrow.png')}}"
                                    alt="arrow"></span>
                        </a>
                    </div>
                </div>
                @endforeach
                <!--<div class="col-12 col-lg-4 text-center mb-lg-0 mb-3">-->
                <!--    <div class="news-image">-->
                <!--        <img class="img-fluid" src="{{ asset('front/images/news1.jpg')}}" alt="">-->
                <!--        <div class="news-date">-->
                <!--            <h3>06</h3>-->
                <!--            <h5>Nov</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--    <div class="news-content text-center">-->
                <!--        <h5>Free Training To Empower Women-->
                <!--            In Community Housing Schemes</h5>-->
                <!--        <p>Leading property management company Trafalgar would like more women to be involved in running-->
                <!--            the...</p>-->
                <!--        <a class="d-flex align-items-center justify-content-center" href="#">Read More-->
                <!--            <span class="arrow-right"><img class="img-fluid" src="{{ asset('front/images/right-arrow.png')}}"-->
                <!--                    alt="arrow"></span>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-12 col-lg-4 text-center mb-lg-0 mb-3">-->
                <!--    <div class="news-image">-->
                <!--        <img class="img-fluid" src="{{ asset('front/images/news2.jpg')}}" alt="">-->
                <!--        <div class="news-date">-->
                <!--            <h3>26</h3>-->
                <!--            <h5>Nov</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--    <div class="news-content text-center">-->
                <!--        <h5>Go private on power, community-->
                <!--            housing schemes advised</h5>-->
                <!--        <p>Property owners in community housing schemes such as Sectional Title complexes and gated-->
                <!--            estates...</p>-->
                <!--        <a class="d-flex align-items-center justify-content-center" href="#">Read More-->
                <!--            <span class="arrow-right"><img class="img-fluid" src="{{ asset('front/images/right-arrow.png')}}"-->
                <!--                    alt="arrow"></span>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--</div>-->

            </div>
        </div>
    </section>
@endif