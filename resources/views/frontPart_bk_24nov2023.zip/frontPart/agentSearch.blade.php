@php $pageMeta = App\Models\StaticPageMetaTag::where('page_name','agent-search')->first(); @endphp
@if(isset($pageMeta) && !empty($pageMeta))
@section('title',$pageMeta->page_title)
@section('meta_keywords',$pageMeta->page_keyword)
@section('meta_description',$pageMeta->page_description)
@endif
@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="{{ route('/') }}">Home</a></li>
              <li><a href="{{ route('agent-search') }}">Agent Search</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing1">
                   @php 
                  $residential_letting_agent = $agentGetBuyCategory['residential_letting_agent'] ;
                  
                $residential_sales_agent = $agentGetBuyCategory['residential_sales_agent'] ;
                
                  $commercial_letting_agent = $agentGetBuyCategory['commercial_letting_agent'];
                        
                        @endphp
                        
                       
            <!------------ new code for agent list ----------->
            
              @if($residential_letting_agent != null)
                    
                    <div class="heading h1_tag mb-0">
                       <h1 style="font-weight:500" class="mb-0">Residential Letting Agent</h1>
                    </div>
                    
                  
                    <div class="d-flex flex-column gap-20">
                        <!--<h6></h6>-->
                       
                        <div class="all_agents">
                           
                             @foreach($residential_letting_agent as $keys => $residential_letting_agents)
                              @php
                            $agentDataLoop  =  $residential_letting_agent[$keys]['agentData']
                            
                            @endphp
                               
                             @if($agentDataLoop->isNotEmpty())
                             @if($keys == 'capeTown')
                             <h6> Cape Town </h6>
                             @elseif($keys == 'portElizabeth')
                             <h6>  Port Elizabeth </h6>
                             @elseif($keys == 'johannesBurg')
                             <h6>  Johannesburg </h6>
                              @elseif($keys == 'durban')
                              <h6>  Durban </h6>
                               @elseif($keys == 'pretoria')
                              <h6>   Pretoria </h6>
                               @elseif($keys == 'eastLondon')
                              <h6>   East London </h6>
                              @elseif($keys == 'innerCity')
                              <h6>   Inner City </h6>
                             @endif
                          
                          
                           @foreach($agentDataLoop as $keysss => $valuesss)
                            <div class="eachagent_view">
                                <img class="img-fluid" src="{{ (isset($valuesss->photo_url) && $valuesss->photo_url != '')?$valuesss->photo_url : asset('front/images/agent-img.png') }}"{{ $valuesss->photo_url }}" alt="{{$valuesss->first_name }}">
                                <div class="agent_name_contact">
                                    <a href="{{ route('agent',['agentid'=> $valuesss->agent_name_slug ]) }}"><h6>{{ucwords($valuesss->first_name) }}</h6></a>
                                    @if(isset($valuesss->mobile_number ))
                                     <p class="mobileshow" data-attr="{{ $valuesss->id }}" style="cursor:pointer;"><span class="icon-phone"></span>Show Contact Number</p>
                                    <p id="mobileshow{{ $valuesss->id }}" style="display:none;"><span class="icon-phone"></span>{{ $valuesss->mobile_number }}</p>
                                    @endif
                                    
                                    <a class="readmore" href="{{ route('agent',['agentid'=> $valuesss->agent_name_slug ]) }}">Read More ></a>
                                </div>
                            </div>
                          @endforeach
                            @endif
                            @endforeach
                        </div>
                       
                    </div>
                   
                    
                    @endif
                    
                    
                    
                    
                      @if($residential_sales_agent != null)
                    
                    <div class="heading mb-0">
                       <h3 style="font-weight:500" class="mb-0">Residential Sales Agent</h3>
                    </div>
                    
                  
                    <div class="d-flex flex-column gap-20">
                        <!--<h6></h6>-->
                       
                        <div class="all_agents">
                           
                             @foreach($residential_sales_agent as $key1 => $residential_sales_agents)
                             
                          
                            
                             @php
                            $agentDataLoop1  =  $residential_sales_agent[$key1]['agentData']
                            
                            @endphp
                             @if($agentDataLoop1->isNotEmpty())
                             @if($key1 == 'capeTown')
                             <h6> Cape Town </h6>
                             @elseif($key1 == 'portElizabeth')
                             <h6>  Port Elizabeth </h6>
                             @elseif($key1 == 'johannesBurg')
                             <h6>  Johannesburg </h6>
                              @elseif($key1 == 'durban')
                              <h6>  Durban </h6>
                               @elseif($key1 == 'pretoria')
                              <h6>   Pretoria </h6>
                              @elseif($key1 == 'eastLondon')
                              <h6>   East London </h6>
                              @elseif($key1 == 'innerCity')
                              <h6>   Inner City </h6>
                             @endif
                            
                          
                           @foreach($agentDataLoop1 as $keysss1 => $valuesss1)
                            <div class="eachagent_view">
                                <img class="img-fluid" src="{{ (isset($valuesss1->photo_url) && $valuesss1->photo_url != '')?$valuesss1->photo_url : asset('front/images/agent-img.png') }}"{{ $valuesss1->photo_url }}" alt="{{$valuesss1->first_name }}">
                                <div class="agent_name_contact">
                                    <a href="{{ route('agent',['agentid'=> $valuesss1->agent_name_slug ]) }}"><h6>{{ucwords($valuesss1->first_name) }}</h6></a>
                                    @if(isset($valuesss1->mobile_number ))
                                     <p class="mobileshow" data-attr="{{ $valuesss1->id }}" style="cursor:pointer;"><span class="icon-phone"></span>Show Contact Number</p>
                                    <p id="mobileshow{{ $valuesss1->id }}" style="display:none;"><span class="icon-phone"></span>{{ $valuesss1->mobile_number }}</p>
                                    @endif
                                    
                                    <a class="readmore" href="{{ route('agent',['agentid'=> $valuesss1->agent_name_slug ]) }}">Read More ></a>
                                </div>
                            </div>
                          @endforeach
                            @endif
                            @endforeach
                        </div>
                       
                    </div>
                   
                    
                    @endif
                    
                    
                       @if($commercial_letting_agent != null)
                    
                    <div class="heading mb-0">
                       <h3 style="font-weight:500" class="mb-0">Commercial Letting agent</h3>
                    </div>
                    
                  
                    <div class="d-flex flex-column gap-20">
                        <!--<h6></h6>-->
                       
                        <div class="all_agents">
                           
                            @foreach($commercial_letting_agent as $key2 => $commercial_letting_agents)
                            @php
                            $agentDataLoop2  =  $commercial_letting_agent[$key2]['agentData']
                           
                            @endphp
                           @if($agentDataLoop2->isNotEmpty())
                             @if($key2 == 'capeTown')
                             <h6> Cape Town </h6>
                             @elseif($key2 == 'portElizabeth')
                             <h6>  Port Elizabeth </h6>
                             @elseif($key2 == 'johannesBurg')
                             <h6>  Johannesburg </h6>
                              @elseif($key2 == 'durban')
                              <h6>  Durban </h6>
                               @elseif($key2 == 'pretoria')
                              <h6>   Pretoria </h6>
                               @elseif($key2 == 'eastLondon')
                              <h6>   East London </h6>
                              @elseif($key2 == 'innerCity')
                              <h6>   Inner City </h6>
                             @endif
                            
                           
                         
                           
                           @foreach($agentDataLoop2 as $keysss2 => $valuesss2)
                            <div class="eachagent_view">
                                <img class="img-fluid" src="{{ (isset($valuesss2->photo_url) && $valuesss2->photo_url != '')?$valuesss2->photo_url : asset('front/images/agent-img.png') }}"{{ $valuesss2->photo_url }}" alt="{{$valuesss2->first_name }}">
                                <div class="agent_name_contact">
                                    <a href="{{ route('agent',['agentid'=> $valuesss2->agent_name_slug ]) }}"><h6>{{ucwords($valuesss2->first_name) }}</h6></a>
                                    @if(isset($valuesss2->mobile_number ))
                                     <p class="mobileshow" data-attr="{{ $valuesss2->id }}" style="cursor:pointer;"><span class="icon-phone"></span>Show Contact Number</p>
                                    <p id="mobileshow{{ $valuesss2->id }}" style="display:none;"><span class="icon-phone"></span>{{ $valuesss2->mobile_number }}</p>
                                    @endif
                                    
                                    <a class="readmore" href="{{ route('agent',['agentid'=> $valuesss2->agent_name_slug ]) }}">Read More ></a>
                                </div>
                            </div>
                          @endforeach
                            @endif
                            @endforeach
                        </div>
                       
                    </div>
                   
                    
                    @endif
            
            <!-------------new code fo agent list -------------->
                        
                        
                
                
                   
                    
                    
                </div>
                <div class="guldenland_sidebar">
                  @include('frontPart/rightBar/rightBarQuickContactForm') 
                    <div class="property_alert">
                        <div class="e-magazine-right-content">
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="{{ asset('front/images/alert.png') }}" alt="alert" />
                                </div>
                                <div class="magazine-content">
                                    <h4>Property Alerts</h4>
                                    <p>Sign up for your customised property alerts delivered
                                        directly to your inbox.</p>
                                </div>
                            </div>
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="{{ asset('front/images/property.png') }}" alt="property" />
                                </div>
                                <div class="magazine-content">
                                    <h4>List Your Property</h4>
                                    <p>List to sell your property with the help of our qualified
                                        real estate professionals.</p>
                                </div>
                            </div>
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="{{ asset('front/images/valuation.png') }}" alt="valuation" />
                                </div>
                                <div class="magazine-content">
                                    <h4>Free Valution</h4>
                                    <p class="mb-0">Request a free property valuation from one of our real
                                        estate agents to find out what your property is worth.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

   @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection

@push('agent-search-js-page')
@include('frontPart.js.agentSearchJs')
@endpush

