@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Property Management Quote Request</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            <div class="heading mb-4">
                <h2>Property Management Quote Request</h2>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing">
                    <div class="maintenance_form_view">
                        <div class="management_form">
                            <form>
                                <div class="maintenance_form_inner">
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="name">Name<span>*</span></label>
                                            <input type="text" class="form-control" id="name">
                                        </div>
                                        <div class="form-group">
                                            <label for="surname">Surname:<span>*</span></label>
                                            <input type="text" class="form-control" id="surname">
                                        </div>
                                    </div>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label>Designation:<span>*</span></label>
                                            <div class="radio-group">
                                              <span>
                                                <input type="radio" id="chairman" name="radio-group" checked="">
                                                <label for="chairman">Complex Chairman</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="director" name="radio-group">
                                                <label for="director">Trustee or Director</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="owner" name="radio-group">
                                                <label for="owner">Owner</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="tenant" name="radio-group">
                                                <label for="tenant">Tenant</label>
                                              </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="scheme">Name of Scheme:<span>*</span></label>
                                            <input type="text" class="form-control" id="scheme">
                                        </div>
                                        <div class="form-group">
                                            <label for="units">Name of Units:<span>*</span></label>
                                            <input type="text" class="form-control" id="units">
                                        </div>
                                        <div class="form-group">
                                            <label for="pro-address">Property Address:<span>*</span></label>
                                            <input type="text" class="form-control" id="pro-address">
                                        </div>
                                        <div class="form-group">
                                            <label for="pro-suburb">Property Suburb:<span>*</span></label>
                                            <input type="text" class="form-control" id="pro-suburb">
                                        </div>
                                        <div class="form-group">
                                            <label for="pro-city">Property City:<span>*</span></label>
                                            <input type="text" class="form-control" id="pro-city">
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email:<span>*</span></label>
                                            <input type="email" class="form-control" id="email">
                                        </div>
                                        <div class="form-group">
                                            <label for="cellphone">Cellphone:<span>*</span></label>
                                            <input type="number" class="form-control" id="cellphone">
                                        </div>
                                        <div class="form-group">
                                            <label for="levy-arrears">Approximate Levy Arrears:<span>*</span></label>
                                            <input type="text" class="form-control" id="levy-arrears">
                                        </div>
                                        <div class="form-group">
                                            <label for="scheme-built">When was your scheme built:<span>*</span></label>
                                            <input type="text" class="form-control" id="scheme-built">
                                        </div>
                                    </div>
                                    <div class="field_row">
                                        <div class="form-group">
                                            <label for="why-agent">Why are you looking for a new managing agent:<span>*</span></label>
                                            <input type="text" class="form-control" id="why-agent">
                                        </div>
                                        <div class="form-group">
                                            <label for="levy-arrears">Do you have any outstanding Annual General Meetings and audited financial statements:<span>*</span></label>
                                            <div class="radio-group">
                                              <span>
                                                <input type="radio" id="yes" name="radio-group" checked="">
                                                <label for="yes">Yes</label>
                                              </span>
                                              <span>
                                                <input type="radio" id="no" name="radio-group">
                                                <label for="no">No</label>
                                              </span>
                                            </div>
                                        </div>
                                    </div>  
                                    <button type="submit" class="form-control">Send</button>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <input type="text" required="" class="form-control" placeholder="Phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
