<script>

$(document).ready(function () {
  
    $(".mobileshow").click(function(){
    
        var getAttr = $(this).attr('data-attr');
        $(this).hide();
        $("#mobileshow"+getAttr).toggle();
    })
})   
</script>