 <section class="about-section">
        <div class="row m-0">
            <div class="col-lg-6 pl-0">
                <div class="wp-video">
                	<video class="wp-video-shortcode w-100" id="video-5-1" preload="metadata" controls="controls" poster="https://webplan.live/front/images/vid-poster.jpg">
                    	<source type="video/mp4" src="https://www.trafalgar.co.za/wp-content/uploads/2016/09/Trafalgar-Final-Render2.mp4?_=1" />
                    	<!--<a href="https://www.trafalgar.co.za/wp-content/uploads/2016/09/Trafalgar-Final-Render2.mp4">-->
                    	<!--    https://www.trafalgar.co.za/wp-content/uploads/2016/09/Trafalgar-Final-Render2.mp4-->
                    	<!--</a>-->
                	</video>
                </div>
                <!--<img class="img-fluid" src="{{ asset('front/images/about-img.jpg')}}" alt="about">-->
            </div>
            <div class="col-lg-6 mt-lg-0 mt-3 d-flex align-items-center">
                <div class="about-section-content">
                    <div class="heading">
                        <h1>About us</h1>
                    </div>
                    <h3>Trafalgar’s core business is property management services
                        for sectional title schemes and home owners associations
                        across South Africa.</h3>
                    <p>Trafalgar has a successful 50-year property management track record, dating back to the opening
                        of the first sectional title registers in South Africa. Trafalgar holds current registration
                        certificates with all the regulatory bodies relevant to managing agents in South Africa: the
                        Estate Agency Affairs Board (“EAAB”), the National Association of Managing Agents (“NAMA”) and
                        the Council for Debt Collectors.</p>
                    <!--<p>Trafalgar combines specialist skills, customised computer information systems, a national-->
                    <!--    infrastructure and economies of scale to provide a comprehensive property management service-->
                    <!--    with client service excellence an overriding objective. Trafalgar’s current portfolio under-->
                    <!--    management covers approximately 85 000 residential units in over 1 400 buildings nationally,-->
                    <!--    managed by seven regional branches and over 550 staff.</p>-->
                    <button class="theme-btn mt-2">Learn More</button>
                </div>
            </div>
        </div>
    </section>