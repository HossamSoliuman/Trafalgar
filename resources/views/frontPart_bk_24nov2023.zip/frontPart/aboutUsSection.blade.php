 <section class="about-section">
        <div class="row m-0">
            <div class="col-lg-6 pl-0">
                <div class="wp-video">
                	<video class="wp-video-shortcode w-100" id="video-5-1" preload="metadata" controls="controls" poster="{{ asset('front/images/vid-poster.jpg')}}">
                    	<source type="video/mp4" src="#" />
                	</video>
                </div>
            </div>
            <div class="col-lg-6 mt-lg-0 mt-3 d-flex align-items-center">
                <div class="about-section-content">
                    <div class="heading">
                        <h1>About us</h1>
                    </div>
                    <h3>Trafalgar’s core business is property management services
                        for sectional title schemes and home owners associations
                        across South Africa.</h3>
                    <p>Trafalgar has a successful 50-year property management track record, dating back to the opening
                        of the first sectional title registers in South Africa. Trafalgar holds current registration
                        certificates with all the regulatory bodies relevant to managing agents in South Africa: the Property Practitioners Regulatory Authority (“PPRA”), the National Association of Managing Agents (“NAMA”) and
                        the Council for Debt Collectors.</p>
                        @php $aboutus = route('about-us'); @endphp
                    <button style='cursor: pointer;' onclick="location.href='{{ $aboutus }}'" class="theme-btn mt-2">Learn More</button>
                </div>
            </div>
        </div>
    </section>