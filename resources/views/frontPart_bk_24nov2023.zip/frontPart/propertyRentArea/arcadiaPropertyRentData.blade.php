@php $pageMeta = App\Models\StaticPageMetaTag::where('page_name','pretoria.property-to-rent-arcadia')->first(); @endphp
@if(isset($pageMeta) && !empty($pageMeta))
@section('title',$pageMeta->page_title)
@section('meta_keywords',$pageMeta->page_keyword)
@section('meta_description',$pageMeta->page_description)
@endif

@extends('layouts.front')

@section('content')
    
    <!-- breadcrumb section  -->
    <div class="breadcrumbs">
      <div class="container">
          <ul></ul>
      </div>
    </div>
    <!-- breadcrumb section  -->
    
    <!-- useful links page section  -->
    <section class="guldenland_section about_page_content mt-2">
        <div class="container">
            <div class="heading h1_tag mb-4">
                <h1>Property To Rent In Arcadia, Pretoria</h1>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing1">
                    <div class="each_manage_section manage-paragraph">
                        <div class="more-content">
                       <p> Apartments to let in the Pretoria suburbs of Arcadia, Hatfield and Sunnyside offer the opportunity to live close to the University of Pretoria and are accordingly very popular with students.</p> 

<p> These suburbs are, however, also close to the city’s top schools and the CBD, so are also sought-after by families and young working people. In addition, they are home to most of the 133 foreign embassies and high commissions located in Pretoria – and the staff of those embassies.</p> 

<p> As a result, there is an enormous range of homes to let in Arcadia, Hatfield and Sunnyside in addition to student flats and rooms. These include two-bedroom apartments to let at rates from around R4500 all the way up to R11 000, depending on location, condition, parking availability and other amenities in the complex. New flats to let close to the Gautrain station and shops in Hatfield are in especially high demand.</p> 
						 <div class="more">
		
<p>	There are also three-bedroom apartments to let at monthly rentals from R5500 to about R10 500, and three-bedroom penthouses (top-floor units with roof courtyards) in Sunnyside at rentals from R7000 to around R12 000. Penthouses in Arcadia and Hatfield cost more, and can rent for as much as R25 000 a month.<p>

<p>Three and four-bedroom simplex and duplex townhouses with small gardens are available to let at rates from R12 000 up to around R20 000 a month, while rentals for three and four-bedroom family homes with swimming pools and garages start at around R15 500 and range up to around R25 000.<p>

<p>Student accommodation in these areas starts at around R1800 a month for a room in a shared flat in Sunnyside and ranges up to around R4500 a month for a room in a commune in upmarket enclaves such as Clydesdale or Eastwood, where many of the gracious older homes have been refurbished and converted to shared accommodation for graduate students as well as “working singles” just starting out on their careers.</p>

<p>There are also many bachelor and one-bedroom apartments to let at rates from around R3800 to R4500 a month in Sunnyside and Arcadia, while rentals for the purpose-built student flats to let in Hatfield close to the university start at around R3200 a month for a bachelor unit. Some homeowners in these areas also have garden rooms and cottages to let, at rates from around R3500.</p>

<p>Arcadia is of course best known as the home of the Union Buildings, designed by Herbert Baker and still the seat of government in Pretoria, which is South Africa’s executive capital. These magnificent buildings are fronted by spacious lawns and gardens that have seen many historic events and gatherings, including the inauguration of Nelson Mandela as SA’s first democratic president in 1994.</p>

<p>Also to be found in Arcadia are the President’s official residence and compound, and the famous Loftus Versveldt Stadium, as well as the Pretoria Art Museum, and numerous restaurants, pubs and nightclubs serving a cosmopolitan population of diplomats, students, artists and sports fans. The area is also a popular destination for visitors to the city, and there are a number of hotels here, including the five-star Sheraton overlooking the Union Buildings gardens.</p>

<p>Sunnyside apartments to let are much in demand among those working in the CBD and those studying at other tertiary institutions such as Rosebank College, the Unisa Centre for Early Childhood Development and the Pretoria campus of the Tshwane University of Technology. The Pretoria Technical High School is also located in this area.</p>

<p>Hatfield was first area outside of the CBD to be developed as a commercial node so it has many office blocks as well as flats, shopping centres and entertainment venues, and it is adjacent to the University of Pretoria. There are also several top-rated schools here including the Pretoria Girls’ and Pretoria Boys’ high schools, Afrikaanse Hoër Meisieskool, Afrikaanse Hoër Seunsskool, Stt Mary’s Diocesan and the Cambridge International school. Hatfield also has a Gautrain station and is developing as a tourist gateway to Pretoria.</p>
					   
						 </div>
                        </div>
                    </div>
                    
                    <div class="each_manage_section guldenland_all_product">
                    	<!--<div class="guldenland_each_product">-->
                    	<!--	<div class="product_img">-->
                    	<!--	   <a href="#"> <img title=" " class="img-fluid" src="https://s3.entegral.net/b/f_eb34e99fa60d4a6d90479da056b0fe1b.jpg" alt=""></a>-->
                    	<!--	</div>-->
                    	<!--	<div class="product_content">-->
                    	<!--		<h4 title="R 2 000">R 2 000</h4>-->
                    	<!--		<small title="Bachelor unit to let in Robertson Street"> Bachelor unit to let in Robertson Street </small>                        -->
                    	<!--		<a title="" href="#"><h3> Robertson St 6</h3></a>               -->
                    	<!--		<p>Newly renovated bachelor unit available to let. Unit consists of open plan bedroom to kitchenette and bathroom. All utilities are on pre-paid which puts the tenant in control of their consumption.</p>-->
                    	<!--		<div class="product_detail">-->
                    	<!--			<span title=""><img src="http://webplan.live/front/images/icon_floor_new.png" alt="icon_floor_new"><small>16 <sup>m²</sup></small></span>-->
                    	<!--		</div>-->
                    	<!--	</div>-->
                    	<!--</div>-->
                    	
                    	 
                            @if(!$propertyDatas->isEmpty())
                              @foreach($propertyDatas as $propertyData)
                               @php
                                $suburb = str_replace(" ","-",$propertyData->suburb);
                                $town = str_replace(" ","-",$propertyData->town);
                                $province = str_replace(" ","-",$propertyData->province);
                                $mandate_saletype = str_replace(" ","-",$propertyData->mandate_saletype);
                               $customUrl = route('property-'.$mandate_saletype,['p_suburb'=>$suburb, 'p_town'=>$town, 'p_province'=>$province,'p_id'=>$propertyData->id,'p_ref'=>$propertyData->property_id]);
                               @endphp
                            <div style="cursor: pointer;" onclick="window.location = '{{ $customUrl }}';" class="guldenland_each_product">
                                <div class="product_img">
                                   <a href="{{ $customUrl }}"> <img title="{{ $propertyData->complex_name." ".$propertyData->unit_number }}" class="img-fluid" src="{{ $propertyData->news_featured_image }}"  alt="{{ $propertyData->headline }}" /></a>
                                </div>
                                <div class="product_content">
                                    <h4  title="{{ 'R '.number_format($propertyData->price,0," "," ") }}" >R {{ number_format($propertyData->price,0," "," ")  }}</h4>
                                    <small title="{{ $propertyData->headline }}" > {{ $propertyData->headline }} </small>
                                    
                                    @if($propertyData->complex_name != "") 
           <a title="{{ $propertyData->complex_name." ".$propertyData->unit_number }}" href="{{ $customUrl }}">
         <h3> {{ $propertyData->complex_name." ".$propertyData->unit_number }}</h3>
          </a>
         @else
          <a title="{{ $propertyData->street_name." ".$propertyData->street_number }}" href="{{ $customUrl }}">
         <h3> {{ $propertyData->street_name." ".$propertyData->street_number }}</h3>
          </a>
         @endif
        
                                    <p>{{ substr($propertyData->description,0,200) }}....
                                   
                                    </p>
                                    @if($propertyData->bedrooms > 0 || $propertyData->bathrooms > 0 || $propertyData->garages > 0 || $propertyData->floor_size > 0)
                                    <div class="product_detail">
                                        @if($propertyData->bedrooms > 0)
                                        <span title="{{ $propertyData->bedrooms }} Bedroom"><img src="{{ asset('front/images/icon_bed_new.png') }}" alt="icon_bed_new">{{ $propertyData->bedrooms }} Bedroom</span>
                                        @endif
                                          @if($propertyData->bathrooms > 0)
                                        <span title="{{ $propertyData->bathrooms }} Bathroom"><img src="{{ asset('front/images/icon_bath_new.png') }}" alt="icon_bath_new">{{ $propertyData->bathrooms }} Bathroom</span>
                                         @endif
                                           @if($propertyData->garages > 0)
                                        <span title="{{ $propertyData->garages }} Garage"><img src="{{ asset('front/images/icon_parking.png') }}" alt="icon_parking"> {{ $propertyData->garages }} Garage</span>
                                           @endif
                                             @if($propertyData->floor_size > 0)
                                        <span title="{{ $propertyData->floor_size }}{{ $propertyData->floor_size_unit }}" ><img src="{{ asset('front/images/icon_floor_new.png') }}" alt="icon_floor_new"><small>{{ $propertyData->floor_size }} <sup>{{ $propertyData->floor_size_unit }}</sup></small></span>
                                        @endif
                                    </div>
                                    @endif
                                </div>
                            </div>
                            @endforeach
                           @else
                           <div class="guldenland_each_product">
                               There are no properties for your selected critera
                            </div>
                           @endif
                           
                             
                             
                            @php
                            if(isset($propertyDatas) && !$propertyDatas->isEmpty()){
                    	
                    	  
                        
                            $suburb_pserach  = str_replace(" ","-",$propertyDatas[0]->suburb);
                            $town_pserach  = str_replace(" ","-",$propertyDatas[0]->town);
                            $province_pserach  = str_replace(" ","-",$propertyDatas[0]->province);
                          
                            }
                       @endphp
                       
                       
                        @php
                                 if(isset($propertyDatas) && !$propertyDatas->isEmpty()){ 
                        $customUrl_pserach = route('to-rent',['url_city'=>$suburb_pserach,'url_town'=>$town_pserach,'url_province'=>$province_pserach,'city'=>$propertyDatas[0]->town]); 
                          }
                             @endphp
                             
                             @if(isset($propertyDatas) && !$propertyDatas->isEmpty())
                    	<div class="view_more_button text-right">
                    	    <a href="{{ $customUrl_pserach }}" class="theme-btn d-inline-block h-auto">View More</a>
                    	</div>
                    @endif
                    </div>
                    
                  
                    
                </div>
                <div class="guldenland_sidebar">
                    @include('frontPart/rightBar/rightBarQuickContactForm') 
                    @include('frontPart/rightBar/rightBarQuickLinkMenu') 
                    @include('frontPart/rightBar/rightBarSocialIcon') 
                    @include('frontPart/rightBar/rightNewsLetter') 
                </div>
            </div>
        </div>
    </section>
    <!-- useful links page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
