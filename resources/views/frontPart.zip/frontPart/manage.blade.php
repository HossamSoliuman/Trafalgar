@extends('layouts.front')

@section('content')
    
    <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Manage</a></li>
              <li><a href="#">Sectional Title And HOA Management</a></li>
          </ul>
      </div>
    </div>
    
    <!-- page section  -->

    <section class="guldenland_section manage_section mt-5">
        <div class="container">
            <div class="heading mb-4">
               <h2>Sectional Title And HOA Management</h2>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing">
                    <div class="each_manage_section">
                        <h4><a href="#">SECTIONAL TITLE MANAGEMENT</a></h4>
                        <p>Trafalgar’s core business is the property management of sectional title schemes and homeowners associations. Trafalgar understands that the management effectiveness of a property directly affects peoples’ homes, lifestyles and the value of their primary assets, which is why we’re dedicated to providing a comprehensive and tailored sectional title management service.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">HOA MANAGEMENT</a></h4>
                        <p>Trafalgar’s core business is the property management of sectional title schemes and homeowners associations.  Trafalgar offers a comprehensive property management service which can be conveniently tailored to the specific needs and context of individual properties. Each property managed by Trafalgar is allocated a dedicated residential portfolio manager as a single point of entry and primary communication channel.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">FINANCIAL MANAGEMENT</a></h4>
                        <p>Our services include:</p>
                        <ul>
                            <li>Monthly levy billing and statement distribution supported by progressive credit control procedures</li>
                            <li>Payment of and accounting for approved expenses, including salaries and wages</li>
                            <li>Surplus funds invested in call accounts to maximise interest earnings</li>
                        </ul>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">FINANCIAL REPORTING</a></h4>
                        <ul>
                            <li>Trafalgar has its own Inhouse Accounting Teams to ensure that we report accurate and timeous figures to our clients on a monthly basis</li>
                            <li>Financial reporting including a Balance Sheet, Income Statement, Levy Roll, Arrears report, Creditors roll and all invoices on request which is held in our Electronic Library</li>
                        </ul>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">DEVELOPER SERVICES</a></h4>
                        <ul>
                            <li>Preparation of initial budget and calculation of levies and common area expenditure</li>
                            <li>Assistance with reviewing Management, Conduct Rules and Memorandum Of Articles (MOA) for Home Owners Associations (HOA)</li>
                        </ul>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">ESTATE MANAGEMENT</a></h4>
                        <p>An Estate Manager will manage contractors, gardeners, cleaners, security guards and maintenance workers, as well as conduct regular inspections and attend to urgent maintenance projects.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">ONLINE SERVICES</a></h4>
                        <p>As a Trafalgar client, you are very welcome to use our online services to update your property management and account information. Simply log in using your pin and password, and gain access to a secure world of online property management information.</p>
                        <span class="read-more">
                            <a href="#">Click here</a>
                        </span>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist contact_sidelist">
                        <h4>Quick Contact</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                     <input type="text" required="" class="form-control" placeholder="Phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <textarea id="message" required="" class="form-control" name="message" placeholder="Message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="sidelist">
                        <h4>Quick Links Menu</h4>
                        <ul>
                            <li><a href="#">NEWSLETTER SIGNUP</a></li>
                            <li><a href="#">OUR BLOG</a></li>
                            <li><a href="#">EMAIL PROPERTY ALERT</a></li>
                            <li><a href="#">BRANCH LOCATOR</a></li>
                            <li><a href="#">PROPERTY PORTALS</a></li>
                        </ul>
                    </div>
                    <div class="sidelist sociallinks_list">
                        <h4>Social Links</h4>
                        <ul>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/facebook.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/twitter.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/youtube.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/linkedin.svg" /></a></li>
                            <li><a href="#"><img class="img-fluid" src="https://webplan.live/front/images/instagram.svg" /></a></li>
                        </ul>
                    </div>
                    <div class="sidelist contact_sidelist">
                        <h4>Newsletter Signup</h4>
                         <form action="" method="post">
                            <input type="hidden" name="_token" value="">                            
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="" id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group ">
                                     <label for="email">Email<span>*</span></label>
                                     <input type="email" class="form-control" placeholder="Email" required="" id="email" name="email">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Submit</button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- page section  -->

    <!-- main footer section  -->

   @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
