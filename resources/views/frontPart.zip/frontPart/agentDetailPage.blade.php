@extends('layouts.front')

@section('content')
  
  <!-- breadbrumb  -->
  <div class="breadcrumbs">
      <div class="container">
          <ul>
              <li><a href="#">Property</a></li>
              <li><a href="#">{{ (isset($agentDetail->first_name))?$agentDetail->first_name:"" }}</a></li>
          </ul>
      </div>
  </div>
  <!-- breadcrumb -->
  
  <!-- agent detail -->
  <section class="agentdetail_section">
      <div class="container">
        <div class="details">
            <div class="agent_image">
                <img class="img-fluid" src="{{ ($agentDetail->photo_url != '')?$agentDetail->photo_url :'https://webplan.live/front/images/agent-img.png' }}" />
            </div>
            <div class="agent_detail">
                <h3>{{ (isset($agentDetail->first_name))?$agentDetail->first_name:"" }}</h3>
                <h4>{{ (isset($agentDetail->job_title))?$agentDetail->job_title:"" }}</h4>
                <div class="agent_social_network">
                    <ul>
                        <li>
                            <span class="icon-phone"></span> <a href="tel:{{ (isset($agentDetail->first_name))?$agentDetail->mobile_number:"" }}">{{ (isset($agentDetail->first_name))?$agentDetail->mobile_number:"" }}</a>
                        </li>
                        <li>
                            <span class="icon-envelope"></span> <a href="mailto:{{ (isset($agentDetail->email))?$agentDetail->email:"" }}">{{ (isset($agentDetail->email))?$agentDetail->email:"" }}</a>
                        </li>
                        <li>
                            <span class="icon-whatsapp"></span> <a href="https://api.whatsapp.com/send?phone={{ (isset($agentDetail->mobile_number))? '+27'.$agentDetail->mobile_number:"" }}&text=hi {{ (isset($agentDetail->first_name))?$agentDetail->first_name:"" }}">Whatsapp Agent</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
      </div>
  </section>
  <!-- agent detail -->
  
  <!-- guldenland section  -->
  <section class="guldenland_section agent_section">
        <div class="container">

            <div class="guldenland_products">
                
                <div class="guldenland_products_listing">
                    <div class="heading mb-0">
                        <h2>View all {{ (isset($agentDetail->first_name))?$agentDetail->first_name:"" }}’s listing</h2>
                    </div>
                    <div class="order_grid_view">
                        <div class="order_view">
                            <span>
                                <b>Order By: </b> 
                                <select id="setSortType" class="form-select">
                                     <option {{ (isset($_GET['sortType']) && $_GET['sortType'] == 'default')? 'selected':'' }} value="default">Default</option>
                                    <option {{ (isset($_GET['sortType']) && $_GET['sortType'] == 'lowtohigh')? 'selected':'' }} value="lowtohigh">Price - low to high</option>
                                    <option {{ (isset($_GET['sortType']) && $_GET['sortType'] == 'hightolow')? 'selected':'' }} value="hightolow">Price - high to low</option>
                                    <option {{ (isset($_GET['sortType']) && $_GET['sortType'] == 'mostrecent')? 'selected':'' }} value="mostrecent">Most Recent</option>
                                    <option {{ (isset($_GET['sortType']) && $_GET['sortType'] == 'alphabat')? 'selected':'' }} value="alphabat">Alphabetical</option>
                                 </select>
                                 <input type="hidden" id="currentValue" value="{{  route('agent',['agentid' => $_GET['agentid'] ]) }}">
                                  <input type="hidden" id="currentPage" value="{{ (isset($_GET['page']) && $_GET['page'] != '')? $_GET['page']:'' }}">
                            </span>
                        </div>
                        <div class="list_map_view">
                            <p class="m-0 mr-3">Showing: {{ $propertyDatas->currentPage() }} - {{ $propertyDatas->count() }} of {{ $propertyDatas->total() }}</p>
                            <a class="list_view" id="showListDiv" href="#"><img class="img-fluid" src="{{ asset('front/images/list.png') }}"/></a>
                            <a class="map_view" id="showMapDiv" href="javascript:void(0)"><img class="img-fluid" src="{{ asset('front/images/map.png') }}"/></a>
                        </div>
                    </div>
                    <div class="mapping_view" id="mapping_view" style="display:none">
                        <div class="guldenland_map_view">
                            <div class="container">
                                <div id="map_tuts" style="width:100%; height:500px; "></div>
                                
                            </div>
                           
                        </div>
                    </div>
                    <div class="guldenland_view" id="showPropertyList" style="display:block">
                        <div class="guldenland_all_product">
                            @if(!empty($propertyDatas))
                              @foreach($propertyDatas as $propertyData)
                            <div class="guldenland_each_product">
                                <div class="product_img">
                                   <a href="{{ route('getPropertyDetail',["propertid"=>$propertyData->property_id]) }}"> <img class="img-fluid" src="{{ $propertyData->news_featured_image }}" /></a>
                                </div>
                                <div class="product_content">
                                    <h4> R {{ number_format($propertyData->price,0," "," ")  }} </h4>
                                  <small>{{ $propertyData->street_number }} , {{ $propertyData->street_name }} , {{ $propertyData->suburb }} , {{ $propertyData->town }} ,{{ $propertyData->province }} </small>
                                    <a href="{{ route('getPropertyDetail',["propertid"=>$propertyData->property_id]) }}"> <h3>{{ $propertyData->headline }}</h3></a>
                                    <p>{{ substr($propertyData->description,0,60) }}....
                                    
                                        <div class="product_detail">
                                            @if($propertyData->bedrooms >= 1)
                                        <span><img src="{{ asset('front/images/icon_bed_new.png') }}">{{ $propertyData->bedrooms }} Bedroom</span>
                                        @endif
                                         @if($propertyData->bathrooms >= 1)
                                        <span><img src="{{ asset('front/images/icon_bath_new.png') }}">{{ $propertyData->bathrooms }} Bathroom</span>
                                         @endif
                                         @if($propertyData->garages >= 1)
                                        <span><img src="{{ asset('front/images/icon_parking.png') }}"> {{ $propertyData->garages }} Garage</span>
                                         @endif
                                         @if($propertyData->floor_size >= 1)
                                        <span><img src="{{ asset('front/images/icon_floor_new.png') }}"><small>{{ $propertyData->floor_size }} <sup>{{ $propertyData->floor_size_unit }}</sup></small></span>
                                         @endif
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @endif
                             <?php if($propertyDatas->total() > 8){ ?>
                            <div class="property_pagination">
                                 {{ $propertyDatas->links() }}
                               
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="contact_sidelist">
                        <h4>Contact {{ (isset($agentDetail->first_name))?$agentDetail->first_name:"" }}</h4>
                        
                         <form action="{{ route('agent-contact-mail') }}" method="post">
                                @csrf
                            <div class="row">
                              <div class="col-12">
                                  <div class="form-group">
                                    <label for="username">Name<span>*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter name" required id="username" name="username">
                                  </div>
                              </div>
                              <div class="col-6 pr-2">
                                  <div class="form-group ">
                                    <label for="email">Email<span>*</span></label>
                                     <input type="email" class="form-control" placeholder="Enter email" required id="email" name="email">
                                  </div>
                              </div>
                             
                              <input type="hidden"    name="getAgentEmail" value="{{ $agentDetail->email }}">
                               <input type="hidden"    name="pageName" value="agent">
                              <input type="hidden"    name="getId" value="{{ (isset($_GET['agentid']))?$_GET['agentid']:""}}">
                              <div class="col-6 pl-2">
                                  <div class="form-group">
                                    <label for="phone">Phone<span>*</span></label>
                                     <input type="text" required class="form-control" placeholder="Enter phone" id="phone" name="phone">
                                  </div>
                              </div>
                              <div class="col-12">
                                  <div class="form-group">
                                    <label for="message">Message<span>*</span></label>
                                   
                                    <textarea id="message" required class="form-control" name="message" placeholder="Enter message" rows="4" style="width:100%;"></textarea>
                                  </div>
                              </div>
                              <div class="col-12">
                                  <button type="submit" class="form-control">Send message</button>
                              </div>
                              <div class="col-12">
                                  <p class="term-policy">
                                      By continuing I understand and agree with Trafalgar <a href="{{ route('terms-conditions') }}" >Terms & Conditions</a> and <a href="#">Privacy Policy</a>.
                                  </p>
                              </div>
                            </div>
                        </form>
                    </div>
                    <div class="property_alert">
                        <div class="e-magazine-right-content">
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="https://webplan.live/front/images/alert.png" alt="">
                                </div>
                                <div class="magazine-content">
                                    <h4>Property Alerts</h4>
                                    <p>Sign up for your customised property alerts delivered
                                        directly to your inbox.</p>
                                </div>
                            </div>
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="https://webplan.live/front/images/property.png" alt="">
                                </div>
                                <div class="magazine-content">
                                    <h4>List Your Property</h4>
                                    <p>List to sell your property with the help of our qualified
                                        real estate professionals.</p>
                                </div>
                            </div>
                            <div class="each-magazine">
                                <div class="icon-div">
                                    <img class="img-fluid" src="https://webplan.live/front/images/valuation.png" alt="">
                                </div>
                                <div class="magazine-content">
                                    <h4>Free Valution</h4>
                                    <p class="mb-0">Request a free property valuation from one of our real
                                        estate agents to find out what your property is worth.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
   <!-- end guldenland section  -->

    <!-- footer top section  -->

    <section class="footer_top_section footer_top_section_bgwhite">
        <div class="section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <div class="footer_top_content">
                            <h5>Property for rent <br />
                                in Gauteng</h5>
                            <div class="content_list d-flex justify-content-around">
                                <ul>
                                    <li><a href="#">Alberto</a></li>
                                    <li><a href="#">Benoni</a></li>
                                    <li><a href="#">Boksburg</a></li>
                                    <li><a href="#">Centurion</a></li>
                                    <li><a href="#">Edenvale</a></li>
                                    <li><a href="#">Johannesburg</a></li>
                                    <li><a href="#">Kempton Park</a></li>
                                </ul>
                                <ul>
                                    <li><a href="#">Midrand</a></li>
                                    <li><a href="#">Pretoria</a></li>
                                    <li><a href="#">Randburg</a></li>
                                    <li><a href="#">Roodepoort</a></li>
                                    <li><a href="#">Sandton</a></li>
                                    <li><a href="#">Soweto</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg col-md-6">
                        <div class="footer_top_content">
                            <h5>Property for rent <br class="d-none d-md-block" />
                                in Western Cape</h5>
                            <div class="content_list">
                                <ul>
                                    <li><a href="#">Bellville</a></li>
                                    <li><a href="#">Cape Town</a></li>
                                    <li><a href="#">Durbanville</a></li>
                                    <li><a href="#">Hermanus</a></li>
                                    <li><a href="#">Paarl</a></li>
                                    <li><a href="#">Somerset West</a></li>
                                    <li><a href="#">Stellenbosch</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg col-md-6">
                        <div class="footer_top_content">
                            <h5>Property for rent <br class="d-none d-md-block" />
                                in KwaZulu Natal</h5>
                            <div class="content_list">
                                <ul>
                                    <li><a href="#">Ballito</a></li>
                                    <li><a href="#">Durban</a></li>
                                    <li><a href="#">Hillcrest</a></li>
                                    <li><a href="#">Pietermaritzburg</a></li>
                                    <li><a href="#">Pinetown</a></li>
                                    <li><a href="#">Umhlanga</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg col-md-6">
                        <div class="footer_top_content">
                            <h5>Rest of South Africa <br /><br class="brr d-none d-md-block" /></h5>
                            <div class="content_list">
                                <ul>
                                    <li><a href="#">Bloemfontein</a></li>
                                    <li><a href="#">East London</a></li>
                                    <li><a href="#">Nelspruit</a></li>
                                    <li><a href="#">Polokwane</a></li>
                                    <li><a href="#">Port Elizabeth</a></li>
                                    <li><a href="#">Rustenburg</a></li>
                                    <li><a href="#">Witbank</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- footer top section  -->

    <!-- main footer section  -->

   @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection

@push('agent-detail-page-js')
@include('frontPart.js.agentDetailPageJs')
@endpush
