@extends('layouts.front')

@section('content')
  
  
<!--job banner-->
<section class="jobbanner-section">
    <div class="jobbanner-text">
        <h1>Trafalgar Jobs</h1>
        <h4>Search for job Opportunities at Trafalgar</h4>
    </div>
</section>
<!--end job banner-->
  
<!--job search form-->
<div class="container">
    <section class="jobsearch_form_section">
        <form>
            <div class="form-group">
                <label for="keyword">Keyword</label>
                <input type="text" class="form-control" id="keyword" placeholder="keyword">
            </div>
            <div class="form-group">
                <label for="jobtype">Job Type</label>
                <div class="icon_select">
                    <select id="jobtype" class="form-control">
                      <option>Default select</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="location">Location</label>
                <input type="text" class="form-control" id="location" placeholder="location">
            </div>
            <button type="submit" class="btn btn-primary theme-btn">Search Jobs</button>
            </form>
    </section>
</div>
<!--end job search form-->

<!-- job listing section  -->
    <section class="joblisting_section">
        <div class="joblisting">
            <div class="container">
                <div class="each_job">
                    <div class="job_title">
                        <h4>Portfolio Administrator</h4>
                        <p>Admin</p>
                    </div>
                    <div class="job_location">
                        <h6>Location</h6>
                        <p>Johannesburg</p>
                    </div>
                    <div class="job_type">
                        <h6>Job Type</h6>
                        <p>Full Time</p>
                    </div>
                    <div class="job_posted">
                        <h6>Posted</h6>
                        <p>12 Admin ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="joblisting">
            <div class="container">
                <div class="each_job">
                    <div class="job_title">
                        <h4>Portfolio Administrator Senior</h4>
                        <p>Admin</p>
                    </div>
                    <div class="job_location">
                        <h6>Location</h6>
                        <p>Johannesburg</p>
                    </div>
                    <div class="job_type">
                        <h6>Job Type</h6>
                        <p>Full Time</p>
                    </div>
                    <div class="job_posted">
                        <h6>Posted</h6>
                        <p>12 Admin ago</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="container ">
        <div class="w-75 m-auto">
            <div class="property_pagination">
            	<nav>
            		<ul class="pagination">  
            		<li class="page-item disabled" aria-disabled="true" aria-label="« Previous">
            			<span class="page-link" aria-hidden="true">‹</span>
            		</li>
            		<li class="page-item active" aria-current="page"><span class="page-link">1</span></li>
            		<li class="page-item"><a class="page-link" href="#">2</a></li>
            		<li class="page-item"><a class="page-link" href="#">3</a></li>
            		<li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span></li>
            		<li class="page-item"><a class="page-link" href="#">5</a></li>
            		<li class="page-item">
            			<a class="page-link" href="#" rel="next" aria-label="Next »">›</a>
            		</li>
            		</ul>
            	</nav>
            </div>
        </div>
    </div>
<!-- end job listing section  -->

<!-- footer top section  -->

    <section class="footer_top_section anotherpage_footer">
        
    </section>

<!-- footer top section  -->

<!-- main footer section  -->

@include('frontPart/mainFooter')

<!-- main footer section  -->

<!-- copyright section  -->
@endsection

@push('tagger-script-property-search-result-page')
@include('frontPart.js.propertySearchResultTagger')
@endpush
