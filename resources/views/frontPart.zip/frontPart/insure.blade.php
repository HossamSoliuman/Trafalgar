@extends('layouts.front')

@section('content')
    
    <!--about banner-->
    <section class="jobbanner-section insure_top_banner">
        <div class="jobbanner-text">
            <h1>Insurance</h1>
        </div>
    </section>
    <!--about banner-->
    
    <!-- about page section  -->
    <section class="guldenland_section about_page_content mt-5">
        <div class="container">
            <div class="heading">
                <div class="manage-paragraph text-justify">
                    <p>Trafalgar Financial Services (“TFS”) is a boutique financial services company specialising in a range of property financial services products, targeted at residential estates and complexes across South Africa. TFS acts as a broker for an insured property book value of approximately R133 billion and is registered with the Financial Services Board (License number: 1441) and the National Credit Regulator (NCRCP: 2678). TFS also offers a “niche” excess waiver product for sectional title schemes underwritten by Hollard. Our longstanding relationships with respected insurers and underwriters, customised systems and infrastructure, allow us to offer tailored products, at highly competitive rates, supported by world-class customer service.</p>
                </div>
            </div>
            <div class="property-solution online_services_view mb-4">
                <div class="container">
                    <div class="online_services_ mt-4">
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img class="img-fluid" src="https://webplan.live/front/images/shareblock.svg" alt="">
                            </div>
                            <h5>Sectional Title, HOA & Shareblock Insurance</h5>
                            <p>Specialised sectional title cover including free market leading trustee indemnity cover</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/trafex.svg" alt="">
                            </div>
                            <h5>Trafex</h5>
                            <p>Safeguard against unexpected and unpleasant insurance excesses</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/claim.svg" alt="">
                            </div>
                            <h5>Claims</h5>
                            <p>Lodge claim details online for fast and efficient insurance claim support</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/faq.svg" alt="">
                            </div>
                            <h5>Frequently Asked Questions</h5>
                            <p>All the answers to commonly asked questions and concerns</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                        <div class="each-property-solution">
                            <div class="eachimg">
                                <img src="https://webplan.live/front/images/contact.svg" alt="">
                            </div>
                            <h5>Contact Details & Quotations</h5>
                            <p>Contact us direct or complete your contactdetails for a broker to be in touch with you</p>
                            <button class="theme-btn">Read More</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="guldenland_products">
                <div class="guldenland_products_listing manage_section_listing">
                    <div class="each_manage_section">
                        <h4><a href="#">SECTIONAL TITLE INSURANCE</a></h4>
                        <p>Legislation, set out in sections 3(1)(h) and 3(1)(i) of the Sectional Titles Schemes Management Act, 2011, requires that all bodies corporate have in force insurance cover and as more fully detailed in Regulations 3 & 23. Trafalgar Financial Services, is the market leading, and…</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">HOA AND SHAREBLOCK INSURANCE</a></h4>
                        <p>Home Owners Associations (HOA’s) & Shareblock companies, while not legally obligated to have insurance cover, would be prudent to have at the very least (third party) public liability, directors’ liability and common property cover.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section">
                        <h4><a href="#">CLAIMS</a></h4>
                        <p>All claims must be reported either (preferably) directly to Trafalgar Financial Services electronically to claims@trafalgar.co.za or telephonically on 0861 66 44 44, or alternatively to your portfolio manager direct.</p>
                        <span class="read-more">
                            <a href="#">Read More</a>
                        </span>
                    </div>
                    <div class="each_manage_section text-center">
                        <a class="mb-1 d-block" style="color:#6e0d16;" href="#">Click here to contact Trafalgar Financial Services</a>
                        <p class="mb-1">Trafalgar Financial Services (TFS) after hours number for claims (this number is specifically for clients insured through TFS).</p>
                        <p class="mb-1">AFTER HOURS CLAIMS NO. FOR EXTREME EMERGENCIES: <b>072 972 0812</b></p>
                    </div>
                </div>
                <div class="guldenland_sidebar">
                    <div class="sidelist">
                        <h4>Registration Certificates For Trafalgar Property Management (Pty) Ltd</h4>
                        <ul>
                            <li><a href="#">Estate Agency Affairs Board (EAAB) Certificate</a></li>
                            <li><a href="#">National Association of Managing Agents (NAMA) Certificate</a></li>
                            <li><a href="#">Council for Debt Collectors</a></li>
                            <li><a href="#">Professional Indemnity Cover</a></li>
                            <li><a href="#">South African Property Owners Association (SAPOA) Certificate</a></li>
                        </ul>
                    </div>
                    <div class="sidelist">
                        <h4>Registration certificates for Trafalgar Financial Services (Pty) Ltd</h4>
                        <ul>
                            <li><a href="#">Financial Services Board</a></li>
                            <li><a href="#">Registered Credit Provider</a></li>
                            <li><a href="#">FIA Membership Certificate</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- about page section  -->

    <!-- main footer section  -->

    @include('frontPart/mainFooter')

    <!-- main footer section  -->

    <!-- copyright section  -->
@endsection
