  <section class="header_section">
        <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div> <!-- .site-mobile-menu -->

        <div class="site-navbar-wrap">
            <div class="site-navbar-top">
                <div class="container py-2">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-5">
                            <div class="d-flex mr-auto email-phone">
                                <a href="#" class="d-flex align-items-center mr-4">
                                    <span class="icon-phone mr-2"></span>
                                    <span class="d-none d-md-inline-block">
                                    @if($setting->website_contact_no) {{ $setting->website_contact_no }} @endif
                                    </span>
                                </a>
                                <a href="#" class="d-flex align-items-center mr-auto">
                                    <span class="icon-envelope mr-2"></span>
                                    <span class="d-none d-md-inline-block"> @if($setting->website_email) {{ $setting->website_email }} @endif</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-7 text-right top_right_text">
                            <div class="mr-auto">
                                <a href="#" class="p-2 pl-0">Online services</a>
                                <a href="https://trafalgar.estatemate.co.za/login" class="p-2 pl-0">Property app</a>
                                <a href="#" class="p-2 pl-0">Property search</a>
                                <a href="http://webgui.unibase.co.za/scripts/eri.dll?pagename=sectitlelandtrarev1revMW1" class="p-2 pl-0">Property portal</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="site-navbar site-navbar-target js-sticky-header">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-6 col-lg-3">
                            <a href="/">
                                <img class="header_logo" src="{{ asset('front/images/logo.png')}}" alt="logo">
                            </a>
                        </div>
                        <div class="col-6 col-lg-9">
                            <nav class="site-navigation text-right" role="navigation">
                                <div class="container">
                                    <div
                                        class="d-inline-block d-lg-none ml-md-0 mr-auto py-sm-2 py-md-3 menu-hamburger">
                                        <a href="#" class="site-menu-toggle js-menu-toggle"><span
                                                class="icon-menu h3"></span></a>
                                    </div>

                                    <ul class="site-menu main-menu js-clone-nav d-none d-lg-block p-0">
                                        <li class="active"><a href="#home-section" class="nav-link">Home</a></li>
                                        <li class="has-children">
                                            <a href="#" class="nav-link">Property search</a>
                                            <ul class="dropdown arrow-top">
                                                <li><a href="#" class="nav-link">Residential to Rent</a></li>
                                                <li><a href="#" class="nav-link">Commercial to Rent</a></li>
                                                 <li><a href="#" class="nav-link">Residential for Sale</a></li>
                                                  <li><a href="#" class="nav-link">Commercial for Sale</a></li>
                                            </ul>
                                        </li>
                                        <li class="has-children">
                                            <a href="#" class="nav-link">Rent or sell</a>
                                            <ul class="dropdown arrow-top">
                                                <li><a href="#" class="nav-link">Rent your Home</a></li>
                                                <li><a href="#" class="nav-link">Sell your Home</a></li>
                                                   <li><a href="#" class="nav-link">Agents</a></li>
                                                      <li><a href="#" class="nav-link">Offices</a></li>
                                            </ul>
                                        </li>
                                        <li class="has-children">
                                            <a href="#" class="nav-link">property management</a>
                                            <ul class="dropdown arrow-top">
                                                <li><a href="#" class="nav-link">Sectional Title & HOA Management</a></li>
                                                <li><a href="#" class="nav-link">Commercial Property Management</a></li>
                                                  <li><a href="#" class="nav-link">Estate Management</a></li>
                                                    <li><a href="#" class="nav-link">Property Developer Services</a></li>
                                                      <li><a href="#" class="nav-link">Training Courses</a></li>
                                            </ul>
                                        </li>
                                        <li class="has-children">
                                            <a href="#" class="nav-link">financial services</a>
                                            <ul class="dropdown arrow-top">
                                                <li><a href="#" class="nav-link">Property Insurance</a></li>
                                                <li><a href="#" class="nav-link">Property Finance</a></li>
                                            </ul>
                                        </li>
                                        <li class="has-children">
                                            <a href="#" class="nav-link">about</a>
                                            <ul class="dropdown arrow-top">
                                                <li><a href="{{ url('/joblist') }}" class="nav-link">Careers</a></li>
                                                <li><a href="#" class="nav-link">News</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#contact-section" class="nav-link">Contact</a></li>
                                        <li class="has-children">
                                            <a href="#" class="nav-link"><span class="icon-user-circle-o navicon"></span></a>
                                            <ul class="dropdown arrow-top">
                                                
                                                @guest
                            @if (Route::has('login'))
                                <li >
                                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li >
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                       
                        
                        
                        @else
                            <li >
                                <a  class="nav-link" href="#" >
                                    {{ ucfirst(Auth::user()->name) }}
                                </a>
                                </li>
                                <li >
                                    <a  class="nav-link" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                              
                            </li>
                        @endguest
                                                
                                                
                                                
                                                <!--<li><a href="{{ url('/login') }}" class="nav-link">Login</a></li>-->
                                                <!--<li><a href="{{ url('/register') }}" class="nav-link">Register</a></li>-->
                                                <!--<li><a href="{{ url('/profile') }}" class="nav-link">profile</a></li>-->
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>