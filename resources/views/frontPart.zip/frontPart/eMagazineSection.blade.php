  <section class="e-magazine section-padding">
        <div class="container">
            <div class="heading">
                <h2>E-Magazine</h2>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="magazine-image-section text-center">
                        <img class="img-fluid" src="{{ asset('front/images/magazine-image.jpg')}}" alt="magazine">
                        <button class="theme-btn"> View Magazine </button>
                    </div>
                </div>
                <div class="col-lg-6 e-magazine-right-content">
                    <div class="each-magazine">
                        <div class="icon-div">
                            <img src="{{ asset('front/images/alert.png')}}" alt="">
                        </div>
                        <div class="magazine-content">
                            <h4>Property Alerts</h4>
                            <p>Sign up for your customised property alerts delivered
                                directly to your inbox.</p>
                        </div>
                    </div>
                    <div class="each-magazine">
                        <div class="icon-div">
                            <img src="{{ asset('front/images/property.png')}}" alt="">
                        </div>
                        <div class="magazine-content">
                            <h4>List Your Property</h4>
                            <p>List to sell your property with the help of our qualified
                                real estate professionals.</p>
                        </div>
                    </div>
                    <div class="each-magazine">
                        <div class="icon-div">
                            <img src="{{ asset('front/images/valuation.png')}}" alt="">
                        </div>
                        <div class="magazine-content">
                            <h4>Free Valution</h4>
                            <p>Request a free property valuation from one of our real
                                estate agents to find out what your property is worth.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>